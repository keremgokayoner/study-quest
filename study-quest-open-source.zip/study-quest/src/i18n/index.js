// Çok dilli altyapı. Kaynak dil Türkçe: kodda Türkçe metin yazılır, t('Türkçe metin') çağrılır.
// Yeni dil eklemek için: i18n/<kod>.js dosyası oluştur ({ 'Türkçe metin': 'Çeviri' }), aşağıdaki DICTS ve LANGS'a ekle.
import en from './en';

export const LANGS = [
  { id: 'tr', name: 'Türkçe', flag: '🇹🇷', ai: 'Türkçe' },
  { id: 'en', name: 'English', flag: '🇬🇧', ai: 'English' },
];
const DICTS = { en };

let lang = 'tr';
export const missing = new Set(); // test için: çevirisi eksik anahtarlar
export const setLang = (l) => { lang = DICTS[l] || l === 'tr' ? l : 'tr'; };
export const getLang = () => lang;
export const aiLangName = () => LANGS.find((l) => l.id === lang)?.ai || 'Türkçe';
export const detectLang = () => {
  const n = (typeof navigator !== 'undefined' && navigator.language) || 'tr';
  return n.toLowerCase().startsWith('tr') ? 'tr' : 'en';
};

// {ad} biçimli yer tutucuları destekler: T('Bugün {n} görev kaldı', { n: 3 })
export function T(src, vars) {
  let s = src;
  if (lang !== 'tr') {
    const tr = DICTS[lang]?.[src];
    if (tr === undefined) missing.add(src);
    else s = tr;
  }
  return vars ? s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? '')) : s;
}

import { useStore } from '../store/useStore';
import { T } from './index';

// Dil değişince bileşeni yeniden çizdirir.
export function useT() {
  useStore((s) => s.lang);
  return T;
}

import { useEffect, useState } from 'react';
import { useT } from './i18n/useT';
import { useStore } from './store/useStore';
import XPBar from './components/XPBar.jsx';
import StreakFlame from './components/StreakFlame.jsx';
import Today from './pages/Today.jsx';
import Focus from './pages/Focus.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Flashcards from './pages/Flashcards.jsx';
import Exams from './pages/Exams.jsx';
import Coach from './pages/Coach.jsx';
import PdfLab from './pages/PdfLab.jsx';
import Feynman from './pages/Feynman.jsx';
import Shop from './pages/Shop.jsx';
import Settings from './pages/Settings.jsx';
import Plan from './pages/Plan.jsx';
import Language from './pages/Language.jsx';
import Onboarding from './pages/Onboarding.jsx';
import Effects from './components/Effects.jsx';
import Mascot from './components/Mascot.jsx';
import { useReminders } from './hooks/useReminders';

const TABS = [
  { id: 'today', label: '📋 Bugün', Page: Today },
  { id: 'plan', label: '🗓️ Plan', Page: Plan },
  { id: 'focus', label: '⏱️ Odak', Page: Focus },
  { id: 'cards', label: '🃏 Kartlar', Page: Flashcards },
  { id: 'exams', label: '📝 Deneme', Page: Exams },
  { id: 'dash', label: '📈 Pano', Page: Dashboard },
  { id: 'coach', label: '🤖 Bolt (AI Koç)', Page: Coach },
  { id: 'pdf', label: '📄 PDF Analiz', Page: PdfLab },
  { id: 'feynman', label: '🎙️ Feynman', Page: Feynman },
  { id: 'shop', label: '🛒 Mağaza', Page: Shop },
  { id: 'lang', label: '🌐 Dil', Page: Language },
  { id: 'settings', label: '⚙️ Ayarlar', Page: Settings },
];

export default function App() {
  const t = useT();
  const hydrated = useStore((s) => s.hydrated);
  const profile = useStore((s) => s.profile);
  const hydrate = useStore((s) => s.hydrate);
  const [tab, setTab] = useState('today');
  const [toast, setToast] = useState('');

  const theme = useStore((s) => s.prefs.theme);
  useReminders();
  useEffect(() => {
    const apply = () => {
      const h = new Date().getHours();
      // Otomatik: akşam/gece koyu tema (parlak ekran gece dikkati ve uykuyu bozar), gündüz açık
      document.documentElement.dataset.theme = theme === 'auto' || !theme ? (h >= 20 || h < 7 ? 'dark' : 'light') : theme;
    };
    apply();
    const id = setInterval(apply, 60000);
    return () => clearInterval(id);
  }, [theme]);
  useEffect(() => {
    const nav = (e) => setTab(e.detail);
    window.addEventListener('mq-nav', nav);
    return () => window.removeEventListener('mq-nav', nav);
  }, []);

  useEffect(() => {
    let t;
    const on = (e) => {
      setToast(e.detail.text);
      clearTimeout(t);
      t = setTimeout(() => setToast(''), 4000);
    };
    window.addEventListener('mq-toast', on);
    return () => window.removeEventListener('mq-toast', on);
  }, []);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  if (!hydrated) return <div className="loading">{t('Yükleniyor…')}</div>;
  if (!profile) return <Onboarding />;

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand"><Mascot size={46} /><h1 className="logo">Study Quest</h1></div>
        <XPBar />
        <StreakFlame />
        <nav>
          {TABS.map((tb) => (
            <button
              key={tb.id}
              className={`nav-btn ${tab === tb.id ? 'active' : ''}`}
              onClick={() => setTab(tb.id)}
            >
              {t(tb.label)}
            </button>
          ))}
        </nav>
        {profile.goal && <div className="goal">🎯 {profile.goal}</div>}
      </aside>

      <main className="content">
        {TABS.map(({ id, Page }) => (
          // Sayfalar açık kalır, böylece Odak sayacı başka sekmeye geçince durmaz.
          <div key={id} className="page" style={{ display: tab === id ? 'block' : 'none' }}>
            <Page />
          </div>
        ))}
      </main>
      {toast && <div className="toast">{toast}</div>}
      <Effects />
    </div>
  );
}

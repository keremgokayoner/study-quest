import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import { useStore } from './store/useStore';
import { initFx } from './logic/fx';
import './styles.css';

initFx(useStore);

createRoot(document.getElementById('root')).render(<App />);

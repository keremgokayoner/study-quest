import { useEffect } from 'react';
import { useStore } from '../store/useStore';
import { todayKey } from '../logic/dates';
import { requiredIds } from '../logic/streak';
import { T } from '../i18n';

const pad = (n) => String(n).padStart(2, '0');

function notify(title, body) {
  try { new Notification(title, { body }); } catch { /* bildirim desteklenmiyorsa sessiz geç */ }
  window.dispatchEvent(new CustomEvent('mq-toast', { detail: { text: title } }));
}

// Uygulama açıkken görev saatlerinde ve akşam "seri koruma" saatinde nazik hatırlatma.
export function useReminders() {
  useEffect(() => {
    const fired = new Set();
    const tick = () => {
      const s = useStore.getState();
      if (!s.hydrated || !s.profile || !s.prefs.reminders) return;
      if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
      const now = new Date();
      const hm = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
      const key = todayKey(now);
      const done = s.days[key]?.done || [];
      const tasks = s.plan[now.getDay()] || [];
      tasks.forEach((t) => {
        const id = `${key}-${t.id}`;
        if (t.time === hm && !done.includes(t.id) && !fired.has(id)) {
          fired.add(id);
          notify(`⏰ ${t.label}`, t.cue || T('Başlama zamanı! Sadece 2 dakika dene.'));
        }
      });
      const left = requiredIds(s.plan, key).filter((id) => !done.includes(id)).length;
      if (s.prefs.guard && hm === (s.prefs.guardTime || '21:00') && left > 0 && !fired.has(`${key}-guard`)) {
        fired.add(`${key}-guard`);
        notify(T('🔥 Serini koru'), T('Bugün {left} zorunlu görev kaldı. Küçük bir adımla başlayabilirsin.', { left }));
      }
    };
    const id = setInterval(tick, 20000);
    tick();
    return () => clearInterval(id);
  }, []);
}

import { useEffect, useState } from 'react';

// Dakikada bir güncellenen "şimdi": akşam saatine göre değişen arayüz parçaları için.
export function useNow() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(id);
  }, []);
  return now;
}

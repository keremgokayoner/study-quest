export const SHOP = [
  {
    id: 'freeze',
    icon: '🧊',
    name: 'Seri Dondurma Koruyucusu',
    cost: 300,
    max: 2,
    desc: 'Bir günü kaçırırsan seri kırılmaz. Otomatik kullanılır; sadece geçmişte canlı bir serin varsa harcanır.',
  },
];

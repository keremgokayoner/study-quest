// Hedef netler. max = o testteki soru sayısı (giriş doğrulaması için).
export const YKS_SUBJECTS = [
  { key: 'tyt-turkce', exam: 'TYT', name: 'Türkçe', target: 29, max: 40 },
  { key: 'tyt-mat', exam: 'TYT', name: 'Matematik', target: 17.75, max: 40 },
  { key: 'tyt-sosyal', exam: 'TYT', name: 'Sosyal', target: 10.75, max: 20 },
  { key: 'tyt-fen', exam: 'TYT', name: 'Fen', target: 10, max: 20 },
  { key: 'ayt-mat', exam: 'AYT', name: 'Matematik', target: 14, max: 40 },
  { key: 'ayt-fizik', exam: 'AYT', name: 'Fizik', target: 13, max: 14 },
  { key: 'ayt-kimya', exam: 'AYT', name: 'Kimya', target: 13, max: 13 },
  { key: 'ayt-biyoloji', exam: 'AYT', name: 'Biyoloji', target: 13, max: 13 },
];

import { T } from '../i18n';

export const subjectLabel = (s) => (s.exam ? `${s.exam} ${T(s.name)}` : T(s.name));

// Haftalık sabit program. Anahtar = Date.getDay() (0 = Pazar ... 6 = Cumartesi)
// required: true olan görevler bitmeden gün "tamam" sayılmaz (seri için).

import { T } from '../i18n';

export const DAY_NAMES = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
export const DAY_SHORT = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
export const dayName = (i) => T(DAY_NAMES[i]);
export const dayShort = (i) => T(DAY_SHORT[i]);

const reading = (p) => ({
  id: `${p}-kitap`,
  label: 'Kitap Okuma',
  time: '22:30',
  type: 'reading',
  xp: 15,
  required: true,
});

const review = (p, label) => ({
  id: `${p}-tekrar`,
  label,
  type: 'review',
  xp: 20,
  required: true,
});

const extra = (p) => ({
  id: `${p}-ek`,
  label: 'Ek soru çözümü / deneme (isteğe bağlı)',
  type: 'questions',
  xp: 30,
  required: false,
});

export const YKS_PLAN = {
  1: [
    { id: 'pzt-soru', label: 'Paragraf + Dil Bilgisi (50 soru)', type: 'questions', xp: 50, required: true },
    review('pzt', 'Konu Tekrarı ve Ödev (Matematik / Paragraf)'),
    reading('pzt'),
  ],
  2: [
    { id: 'sal-soru', label: 'Matematik (50 soru çözümü)', type: 'questions', xp: 50, required: true },
    review('sal', 'Okul Konu Tekrarı / Ödev (Matematik)'),
    reading('sal'),
  ],
  3: [
    { id: 'car-soru', label: 'Fizik + Kimya + Biyoloji (toplam 60 soru)', type: 'questions', xp: 60, required: true },
    review('car', 'Okul Konu Tekrarı / Ödev (Fizik-Kimya-Biyoloji)'),
    reading('car'),
  ],
  4: [
    { id: 'per-soru', label: 'Tarih + Coğrafya (50 soru çözümü)', type: 'questions', xp: 50, required: true },
    review('per', 'Okul Konu Tekrarı / Ödev (Tarih-Coğrafya)'),
    reading('per'),
  ],
  5: [
    { id: 'cum-tr', label: 'TYT Türkçe Denemesi (40 soru / 40 dk)', type: 'exam', xp: 100, required: true },
    { id: 'cum-mat', label: 'TYT Matematik Denemesi (40 soru / 60 dk)', type: 'exam', xp: 100, required: true },
    reading('cum'),
  ],
  6: [
    {
      id: 'cmt-tekrar',
      label: 'Haftalık Konu Tekrarı: TDE, Tarih, Coğrafya, Din',
      type: 'review',
      xp: 40,
      required: true,
    },
    { id: 'cmt-mola', label: 'Mola saatlerini uygula (45+5+10)', type: 'break', xp: 10, required: false },
    extra('cmt'),
    reading('cmt'),
  ],
  0: [
    {
      id: 'pzr-tekrar',
      label: 'Haftalık Konu Tekrarı: Matematik, Fizik, Kimya, Biyoloji',
      type: 'review',
      xp: 40,
      required: true,
    },
    extra('pzr'),
    reading('pzr'),
  ],
};

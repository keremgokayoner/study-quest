// 10. sınıf başlangıç kartları. Kendi kartlarını uygulama içinden ekleyebilirsin.
const c = (id, subject, q, a) => ({ id, subject, q, a });

export const SEED_CARDS = [
  // Matematik
  c('m1', 'Matematik', '5! kaçtır?', '120'),
  c('m2', 'Matematik', 'P(n, r) permütasyon formülü nedir?', 'n! / (n − r)!'),
  c('m3', 'Matematik', 'C(n, r) kombinasyon formülü nedir?', 'n! / (r! · (n − r)!)'),
  c('m4', 'Matematik', 'C(n, r) ile hangi kombinasyon birbirine eşittir?', 'C(n, n − r)'),
  c('m5', 'Matematik', 'Olasılığın temel tanımı nedir?', 'İstenen durum sayısı / tüm durum sayısı'),
  c('m6', 'Matematik', 'Birbirini engelleyen A ve B olayları için P(A ∪ B) = ?', 'P(A) + P(B)'),
  c('m7', 'Matematik', 'ax² + bx + c = 0 denkleminde diskriminant (Δ) nedir? Δ > 0 ise ne olur?', 'Δ = b² − 4ac. Δ > 0 ise birbirinden farklı iki gerçek kök vardır.'),
  c('m8', 'Matematik', 'ax² + bx + c = 0 denkleminde kökler toplamı ve çarpımı nedir?', 'Toplam = −b/a, çarpım = c/a'),
  c('m9', 'Matematik', 'y = ax² + bx + c parabolünün tepe noktasının apsisi (r) nedir?', 'r = −b / (2a)'),
  c('m10', 'Matematik', 'P(x) polinomunun (x − a) ile bölümünden kalan kaçtır?', 'P(a)'),
  c('m11', 'Matematik', 'n kenarlı dışbükey çokgenin iç açıları toplamı nedir?', '(n − 2) · 180°'),
  c('m12', 'Matematik', 'n kenarlı çokgenin köşegen sayısı nedir?', 'n(n − 3) / 2'),

  // Fizik
  c('f1', 'Fizik', 'Ohm yasası nedir?', 'V = I · R'),
  c('f2', 'Fizik', 'Seri bağlı dirençlerde eşdeğer direnç nasıl bulunur?', 'R_eş = R₁ + R₂ + R₃ + ...'),
  c('f3', 'Fizik', 'Paralel bağlı iki direncin eşdeğeri nedir?', '(R₁ · R₂) / (R₁ + R₂)'),
  c('f4', 'Fizik', 'Elektriksel güç formülü nedir?', 'P = V · I'),
  c('f5', 'Fizik', 'Katılarda basınç formülü nedir?', 'P = F / A'),
  c('f6', 'Fizik', 'Sıvı basıncı formülü nedir?', 'P = h · d · g'),
  c('f7', 'Fizik', 'Kaldırma kuvveti formülü nedir?', 'F = V_batan · d_sıvı · g'),
  c('f8', 'Fizik', 'Dalga hızı formülü nedir?', 'v = λ · f'),
  c('f9', 'Fizik', 'Düzlem aynadaki görüntünün özellikleri nelerdir?', 'Sanal, düz, cisimle aynı boyda; aynaya uzaklığı cismin uzaklığına eşit.'),
  c('f10', 'Fizik', 'Mıknatıslarda aynı cins kutuplar birbirine ne yapar?', 'İter (zıt kutuplar çeker).'),

  // Kimya
  c('k1', 'Kimya', 'Mol sayısı (n) kütle ile nasıl hesaplanır?', 'n = m / MA (kütle / mol kütlesi)'),
  c('k2', 'Kimya', 'Avogadro sayısı kaçtır?', '6,02 · 10²³'),
  c('k3', 'Kimya', 'Normal koşullarda (NK) 1 mol gazın hacmi kaçtır?', '22,4 litre'),
  c('k4', 'Kimya', 'İyonik bağ hangi atomlar arasında nasıl oluşur?', 'Metal ile ametal arasında, elektron alışverişiyle.'),
  c('k5', 'Kimya', 'Kovalent bağ nasıl oluşur?', 'Ametal atomlar arasında elektronların ortaklaşa kullanılmasıyla.'),
  c('k6', 'Kimya', 'Hidrojen bağı için H hangi elementlerle bağlı olmalıdır?', 'F, O veya N'),
  c('k7', 'Kimya', 'İdeal gaz denklemi nedir?', 'PV = nRT'),
  c('k8', 'Kimya', 'Boyle yasası ne der?', 'Sabit sıcaklıkta belirli miktar gazın basıncı ile hacmi çarpımı sabittir (P · V = sabit).'),
  c('k9', 'Kimya', 'Molarite (M) nasıl hesaplanır?', 'M = n / V (mol / litre çözelti)'),

  // Biyoloji
  c('b1', 'Biyoloji', 'Mitoz sonunda kaç hücre oluşur ve kromozom sayısı ne olur?', '2 hücre; kromozom sayısı ana hücreyle aynıdır.'),
  c('b2', 'Biyoloji', 'Mayoz sonunda kaç hücre oluşur ve kromozom sayısı ne olur?', '4 hücre; kromozom sayısı yarıya iner.'),
  c('b3', 'Biyoloji', 'Krossing-over mayozun hangi evresinde gerçekleşir?', 'Mayoz I, Profaz I'),
  c('b4', 'Biyoloji', 'Mendel\'in 1. yasası nedir?', 'Ayrılma (gametlerin saflığı) yasası.'),
  c('b5', 'Biyoloji', 'Aa × Aa çaprazlamasında genotip oranı nedir?', '1 AA : 2 Aa : 1 aa'),
  c('b6', 'Biyoloji', 'Ekosistemde enerji ve madde nasıl ilerler?', 'Enerji tek yönlü akar; madde döngü yapar.'),
  c('b7', 'Biyoloji', 'Besin zincirinde üreticiler kimlerdir?', 'Fotosentez veya kemosentezle kendi besinini üreten ototroflardır (bitkiler, bazı bakteriler).'),
];

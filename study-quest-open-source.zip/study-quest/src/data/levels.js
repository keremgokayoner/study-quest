import { T } from '../i18n';

export const XP_BLOCK = 100; // tamamlanan 45+5 dk blok
export const XP_CARD = 3; // doğru bilinen kart
export const XP_EXAM = 30; // deneme sonucu girişi
export const XP_QUESTION = 10; // AI ile çözülen her doğru soru
export const XP_FEYNMAN = 150; // başarılı sesli anlatım (puan >= 60)
export const FEYNMAN_DAILY_CAP = 2; // günde en fazla kaç anlatım XP verir

export const XP_DEEP = 20; // pencereden hiç ayrılmadan biten blok (Derin Odak) bonusu
export const XP_START = 5; // "2 dakika başla" ile başlama ödülü (günde en fazla 3 kez)
export const XP_PACT = 25; // verilen söz tutulursa bonus

// Genel RPG unvanları. 50. seviyede unvan kullanıcının kendi hedefinden gelir ("<hedef> Master").
export const TITLES = [
  { from: 1, name: 'Çaylak' },
  { from: 5, name: 'Çırak' },
  { from: 10, name: 'Kâşif' },
  { from: 17, name: 'Odak Avcısı' },
  { from: 25, name: 'Disiplin Şövalyesi' },
  { from: 35, name: 'Bilge' },
  { from: 50, name: 'Hedef Ustası' },
];

// Seviye L'yi geçmek için gereken XP. Seviye 50'ye toplam ≈ 127.000 XP (günde ~650 XP ile ~6 ay).
export const levelCost = (level) => 100 * level;

export function levelInfo(totalXp, goal = '') {
  let level = 1;
  let rest = totalXp;
  while (rest >= levelCost(level)) {
    rest -= levelCost(level);
    level++;
  }
  let title = T([...TITLES].reverse().find((t) => level >= t.from).name);
  if (level >= 50 && goal.trim()) title = T('{goal} Master', { goal: goal.trim() });
  return { level, into: rest, need: levelCost(level), title };
}

// Feynman: puana göre XP. Puanı model verir, XP'yi biz hesaplarız (modele güvenmeyiz).
export function feynmanXp(score) {
  if (score < 60) return 0;
  return XP_FEYNMAN + (score >= 90 ? 50 : score >= 80 ? 25 : 0);
}

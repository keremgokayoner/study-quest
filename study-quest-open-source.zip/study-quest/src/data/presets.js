import { YKS_PLAN } from './schedule';
import { YKS_SUBJECTS } from './targets';
import { T } from '../i18n';

const task = (id, label, xp, required = true, time = '', cue = '') => ({ id, label, xp, required, time, cue });

// Herkes için dengeli örnek hafta: 6 çalışma günü + 1 dinlenme günü (dinlenme günü seriyi bozmaz).
function balanced() {
  const plan = {};
  [1, 2, 3, 4, 5, 6].forEach((d) => {
    plan[d] = [
      task(`b${d}-odak`, T('Odak bloğu: 2 × 45 dk çalışma'), 40, true, '', T('Eğer akşam yemeğinden kalkarsam, o zaman masama oturup ilk bloğu başlatırım.')),
      task(`b${d}-tekrar`, T('Bugünkü konuyu 15 dk tekrar et'), 20),
      task(`b${d}-oku`, T('Kitap okuma (20 dk)'), 15, false, '22:30'),
    ];
  });
  plan[0] = [task('b0-planla', T('Gelecek haftayı planla (isteğe bağlı)'), 10, false)];
  return plan;
}

// Metinler çağrıldığında seçili dile çevrilir (modül yüklenirken değil).
export function getPresets() {
  return {
    empty: { name: T('Boş başla'), desc: T('Planı kendin kurarsın (ya da AI ile oluşturursun).'), plan: {}, subjects: [], seedCards: false },
    balanced: { name: T('Dengeli hafta'), desc: T('Günde 2 odak bloğu + tekrar, 1 dinlenme günü. Kendine göre düzenle.'), plan: balanced(), subjects: [], seedCards: false },
    yks: {
      name: T('YKS hazırlık (10. sınıf örneği)'),
      desc: T('Hafta içi soru çözümü, Cuma deneme, hafta sonu tekrar + TYT/AYT hedef netleri + başlangıç kartları. (Türkçe içerik)'),
      plan: YKS_PLAN,
      subjects: YKS_SUBJECTS,
      seedCards: true,
    },
  };
}

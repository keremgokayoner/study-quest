// Tüm Gemini istekleri bu dosyadan geçer. UI hiçbir yerde fetch / API anahtarı görmez.
// Electron'da istek ana süreçten gider (electron/main.js); tarayıcıda (vite dev) localStorage + doğrudan fetch.
import { useStore } from '../store/useStore';
import { buildContext } from '../logic/context';
import { T, aiLangName } from '../i18n';

export const DEFAULT_MODEL = 'gemini-3.1-flash-lite';
export const MODEL_SUGGESTIONS = ['gemini-3.1-flash-lite', 'gemini-3.6-flash', 'gemini-3.8-flash'];

export class AIError extends Error {}

// ---------- Ayarlar ----------
export async function getSettings() {
  if (window.api?.getSettings) return window.api.getSettings();
  return {
    hasKey: !!localStorage.getItem('mq-gemini-key'),
    model: localStorage.getItem('mq-gemini-model') || DEFAULT_MODEL,
    encrypted: false,
  };
}

export async function saveSettings({ apiKey, model }) {
  if (window.api?.setSettings) return window.api.setSettings({ apiKey, model });
  if (model) localStorage.setItem('mq-gemini-model', model.trim());
  if (apiKey !== undefined) {
    if (apiKey.trim()) localStorage.setItem('mq-gemini-key', apiKey.trim());
    else localStorage.removeItem('mq-gemini-key');
  }
  return true;
}

// ---------- Düşük seviye istek ----------
const friendly = (status, json) => {
  const msg = json?.error?.message || '';
  if (status === 400 && /API key/i.test(msg)) return T('API anahtarı geçersiz. Ayarlar sekmesinden kontrol et.');
  if (status === 403) return T('Bu anahtarın bu modele erişim izni yok (Ayarlar → model adını değiştirmeyi dene).');
  if (status === 404) return T('Model bulunamadı. Ayarlar sekmesinden başka bir model adı dene.');
  if (status === 429) return T('Ücretsiz kota doldu (dakikalık/günlük limit). Biraz bekle ya da daha hafif bir model seç.');
  return T("Gemini hatası ({n}). Tekrar dene; sürerse Ayarlar'dan başka bir model seç.", { n: status });
};

// Tek bir modele tek istek.
async function send(model, body) {
  if (window.api?.aiGenerate) return window.api.aiGenerate({ model, body });
  const key = localStorage.getItem('mq-gemini-key');
  if (!key) return { error: 'NO_KEY' };
  try {
    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body) }
    );
    return { status: r.status, json: await r.json().catch(() => ({})) };
  } catch (e) {
    return { error: 'NETWORK', message: e.message };
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// 503 = Google tarafında yoğunluk, 500/504 = geçici sunucu sorunu, 429 = kota/hız sınırı
const TRANSIENT = new Set([429, 500, 503, 504]);

// Geçici hatalarda: aynı modeli kısa beklemeyle bir daha dene, olmazsa sıradaki yedek modele geç.
async function call(body) {
  const { model } = await getSettings();
  const chain = [model, ...MODEL_SUGGESTIONS.filter((m) => m !== model)].slice(0, 3);
  let res;
  for (let i = 0; i < chain.length; i++) {
    for (let attempt = 0; attempt < 2; attempt++) {
      res = await send(chain[i], body);
      if (res.error === 'NO_KEY' || !(TRANSIENT.has(res.status) || res.error === 'NETWORK')) break;
      if (attempt === 0) await sleep(1500 + 1000 * i); // kısa bekleme
    }
    if (res.error === 'NO_KEY' || !(TRANSIENT.has(res.status) || res.error === 'NETWORK')) break;
  }
  if (TRANSIENT.has(res.status)) {
    throw new AIError(
      res.status === 429
        ? T("Ücretsiz kota doldu (dakikalık/günlük limit). Biraz bekle ya da Ayarlar'dan başka bir model seç.")
        : T('Gemini şu an çok yoğun (Google sunucu tarafı, senin hatan değil). Birkaç dakika sonra tekrar dene. Yedek modelleri de denedim, hepsi meşguldü.')
    );
  }
  if (res.error === 'NO_KEY') throw new AIError(T('Önce Ayarlar sekmesine Gemini API anahtarını gir.'));
  if (res.error) throw new AIError(T('Bağlantı hatası: {m}', { m: res.message || T('internet var mı?') }));
  if (res.status >= 400) throw new AIError(friendly(res.status, res.json));
  const text = (res.json.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('');
  if (!text) throw new AIError(res.json.promptFeedback?.blockReason ? T('İçerik güvenlik filtresine takıldı.') : T('Boş cevap geldi, tekrar dene.'));
  return text;
}

const user = (...parts) => [{ role: 'user', parts }];
const sys = (text) => ({ systemInstruction: { parts: [{ text: `IMPORTANT: Write every reply and every generated text (questions, cards, summaries, plan items, feedback) in ${aiLangName()}.\n\n${text}` }] } });

async function json(system, contents, schema, temperature = 0.6) {
  const text = await call({
    ...sys(system),
    contents,
    generationConfig: { responseMimeType: 'application/json', responseSchema: schema, temperature },
  });
  try {
    return JSON.parse(text.replace(/^```json|```$/g, '').trim());
  } catch {
    throw new AIError(T('Cevap okunamadı (bozuk JSON). Tekrar dene.'));
  }
}

// ---------- Sistem yönergeleri ----------
const PERSONA = (c) => `Sen "Bolt"sun: Study Quest adlı RPG tarzı çalışma uygulamasının enerjik yapay zekâ yoldaşı.
Öğrenci${c.name ? ` (${c.name})` : ''}: ${c.grade || 'sınıf/seviye belirtilmemiş'}. Hedef sınav/alan: ${c.exam || 'belirtilmemiş'}. Hedefi: ${c.goal || 'belirtilmemiş'}. Sorular ve anlatım öğrencinin seviyesine ve hedef sınavın müfredatına uygun olmalı (Türkiye).
Öğrencinin durumu: Seviye ${c.level} (${c.title}), ${c.streak} günlük seri. Bugün ${c.dayName}; programı: ${c.tasks.join(' | ')}.
Üslup: samimi, kısa, motive edici bir oyun rehberi gibi ("görev", "boss soru", "XP" gibi kelimeler serbest) ama abartma; emoji ölçülü.
Biçim: Markdown, LaTeX, tablo KULLANMA. Düz metin yaz. Formülleri satır içinde yaz (örn. V = I · R, x² + 3x). Cevabını kısa tut.
Öğrenci seviye atladıysa ya da seri yaptıysa kısaca tebrik et, ama her mesajda tekrarlama.`;

const MODES = {
  coach: `GÖREV: Kişisel ders koçu. İstenen derste öğrencinin seviyesine ve hedef sınavına uygun, kademeli zorlukta sorular üret (yalnızca soruları ver, çözümü verme). Öğrenci cevap verince çözümünü ADIM ADIM kontrol et: doğru adımı onayla, hatalı adımı göster ve nedenini kısaca açıkla.`,
  hint: `GÖREV: Sokratik yöntem. Öğrenci takıldığı soruyu sorunca CEVABI ASLA doğrudan söyleme. Her mesajda yalnızca TEK bir yönlendirici soru ya da küçük ipucu ver (önce "Verilenler neler, istenen ne?", sonra ilgili formül/kavram, sonra ilk işlem adımı). Öğrenci takılmaya devam ederse bir sonraki küçük adımı göster ama son sonucu kendisi bulsun. Öğrenci doğru sonuca kendisi ulaşınca tebrik et ve kısa bir özet ver.`,
};

const CHAT_SCHEMA = {
  type: 'OBJECT',
  properties: {
    reply: { type: 'STRING' },
    newCorrect: {
      type: 'INTEGER',
      description: 'Bu mesajda öğrencinin DOĞRU çözdüğünü teyit ettiğin YENİ soru sayısı. Emin değilsen 0. Daha önce saydıklarını tekrar sayma.',
    },
  },
  required: ['reply', 'newCorrect'],
};

// history: [{ role: 'user' | 'model', text }]
export async function chat(history, mode = 'coach') {
  const ctx = buildContext(useStore.getState());
  return json(
    `${PERSONA(ctx)}\n\n${MODES[mode]}`,
    history.map((m) => ({ role: m.role, parts: [{ text: m.text }] })),
    CHAT_SCHEMA
  );
}

// ---------- Flashcard / PDF ----------
const SUBJECTS = ['Matematik', 'Fizik', 'Kimya', 'Biyoloji', 'Türkçe', 'Tarih', 'Coğrafya', 'Diğer'];
const CARDS_SCHEMA = {
  type: 'ARRAY',
  items: {
    type: 'OBJECT',
    properties: { subject: { type: 'STRING', enum: SUBJECTS }, q: { type: 'STRING' }, a: { type: 'STRING' } },
    required: ['subject', 'q', 'a'],
  },
};
const CARD_RULES = `Flashcard kuralları: her kart tek bir bilgiyi yoklasın; "q" kısa bir soru, "a" kısa ve net cevap olsun; ezberlenmeye değer bilgileri seç (formül, tanım, kural, tarih); düz metin kullan.`;

export async function makeFlashcards(text) {
  const cards = await json(
    `Sen bir ders asistanısın (Türkiye müfredatı). Verilen notları Türkçe aralıklı tekrar kartlarına çevir. ${CARD_RULES} En fazla 15 kart üret.`,
    user({ text }),
    CARDS_SCHEMA,
    0.3
  );
  return cards.filter((c) => c.q?.trim() && c.a?.trim());
}

const PDF_SCHEMA = {
  type: 'OBJECT',
  properties: {
    summary: { type: 'STRING' },
    cards: CARDS_SCHEMA,
    quiz: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          q: { type: 'STRING' },
          options: { type: 'ARRAY', items: { type: 'STRING' } },
          answerIndex: { type: 'INTEGER' },
          explanation: { type: 'STRING' },
        },
        required: ['q', 'options', 'answerIndex', 'explanation'],
      },
    },
  },
  required: ['summary', 'cards', 'quiz'],
};

// base64: PDF'in base64'ü (ham, "data:" öneksiz). Gemini satır içi PDF'te ~20 MB sınırı vardır.
export async function analyzePdf(base64) {
  const out = await json(
    `Sen bir ders asistanısın (Türkiye müfredatı). Verilen PDF'i oku ve Türkçe şunları üret:
1) summary: 8-12 cümlelik, başlıksız, düz metin konu özeti.
2) cards: 10-15 flashcard. ${CARD_RULES}
3) quiz: tam 5 soruluk, 4 şıklı (A-D harfi koyma, sadece şık metni), yalnızca PDF içeriğine dayalı test. answerIndex 0-3 arası; explanation tek cümle.`,
    user({ inlineData: { mimeType: 'application/pdf', data: base64 } }, { text: 'Bu PDF için özet, kart ve test üret.' }),
    PDF_SCHEMA,
    0.4
  );
  out.quiz = (out.quiz || []).filter((q) => q.options?.length >= 2 && q.answerIndex >= 0 && q.answerIndex < q.options.length).slice(0, 5);
  out.cards = (out.cards || []).filter((c) => c.q?.trim() && c.a?.trim());
  return out;
}

// ---------- Feynman ----------
const FEYNMAN_SCHEMA = {
  type: 'OBJECT',
  properties: {
    transcript: { type: 'STRING', description: 'Öğrencinin anlattığı metin (ses verildiyse yazıya dökümü).' },
    score: { type: 'INTEGER', description: '1-100 arası anlatım kalitesi.' },
    praise: { type: 'ARRAY', items: { type: 'STRING' } },
    missing: { type: 'ARRAY', items: { type: 'STRING' } },
    corrections: { type: 'ARRAY', items: { type: 'STRING' } },
    feedback: { type: 'STRING' },
  },
  required: ['transcript', 'score', 'praise', 'missing', 'corrections', 'feedback'],
};

// input: { topic, text } veya { topic, audioBase64 } (audio/wav)
export async function evaluateFeynman({ topic, text, audioBase64 }) {
  const ctx = buildContext(useStore.getState());
  const parts = [{ text: `Konu: ${topic || '(öğrenci belirtmedi, anlatımdan çıkar)'}` }];
  if (audioBase64) parts.push({ inlineData: { mimeType: 'audio/wav', data: audioBase64 } });
  else parts.push({ text: `Öğrencinin anlatımı:\n${text}` });
  const out = await json(
    `${PERSONA(ctx)}

GÖREV: Feynman tekniği değerlendirmesi. Öğrenci bir konuyu kendi cümleleriyle anlattı. Bir öğretmen gözüyle değerlendir:
- transcript: ses verildiyse anlatımı olduğu gibi yazıya dök; metin verildiyse aynen yaz.
- score (1-100): doğruluk %50, kapsam/eksiksizlik %30, anlaşılırlık/kendi cümleleriyle anlatma %20. Çok kısa (birkaç cümle) ya da ezber/okuma gibi anlatıma 50'nin üzerini verme. Dürüst puan ver; şişirme.
- praise: doğru anlaşılan noktalar (en çok 4). missing: eksik kalan önemli noktalar. corrections: yanlış söylenenler ve doğrusu (yoksa boş dizi).
- feedback: Bolt üslubunda 2-3 cümlelik motive edici genel değerlendirme.`,
    user(...parts),
    FEYNMAN_SCHEMA,
    0.3
  );
  out.score = Math.max(1, Math.min(100, Math.round(out.score)));
  return out;
}

// Anahtarı/modeli test etmek için (Ayarlar → Test et)
export async function ping() {
  const text = await call({ contents: user({ text: 'Sadece "tamam" yaz.' }), generationConfig: { maxOutputTokens: 20 } });
  return text.trim();
}

// ---------- Dosya yardımcıları ----------
export const blobToBase64 = (blob) =>
  new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1]);
    r.onerror = () => reject(new AIError(T('Dosya okunamadı.')));
    r.readAsDataURL(blob);
  });

// MediaRecorder çıktısı (webm/opus) Gemini'nin desteklediği formatlarda değil → 16 kHz mono WAV'a çevir.
export async function toWav(blob) {
  const ac = new AudioContext();
  const buf = await ac.decodeAudioData(await blob.arrayBuffer());
  ac.close();
  const rate = 16000;
  const off = new OfflineAudioContext(1, Math.ceil(buf.duration * rate), rate);
  const src = off.createBufferSource();
  src.buffer = buf;
  src.connect(off.destination);
  src.start();
  const pcm = (await off.startRendering()).getChannelData(0);
  const v = new DataView(new ArrayBuffer(44 + pcm.length * 2));
  const w = (o, str) => [...str].forEach((ch, i) => v.setUint8(o + i, ch.charCodeAt(0)));
  w(0, 'RIFF'); v.setUint32(4, 36 + pcm.length * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  w(36, 'data'); v.setUint32(40, pcm.length * 2, true);
  pcm.forEach((x, i) => v.setInt16(44 + i * 2, Math.max(-1, Math.min(1, x)) * 0x7fff, true));
  return new Blob([v], { type: 'audio/wav' });
}

// ---------- Erteleme kurtarıcı ----------
const STEPS_SCHEMA = {
  type: 'OBJECT',
  properties: {
    starter: { type: 'STRING', description: '2 dakikada yapılabilecek, çok küçük ilk hareket.' },
    steps: { type: 'ARRAY', items: { type: 'STRING' }, description: '3 küçük adım (her biri en fazla 5-10 dk).' },
    note: { type: 'STRING', description: 'Nedene uygun tek cümlelik, yargılamayan destek.' },
  },
  required: ['starter', 'steps', 'note'],
};

export async function microSteps(task, reason) {
  const ctx = buildContext(useStore.getState());
  return json(
    `${PERSONA(ctx)}

GÖREV: Öğrenci "${task.label}" görevini ertelemek istiyor. Neden: "${reason}".
Yargılama, ders verme. Görevi sürtünmesi çok düşük küçük adımlara böl: önce 2 dakikalık somut bir "starter" (örn. "kitabı aç, ilk soruyu oku"), sonra 3 kısa adım, sonra nedene uygun tek cümlelik destek notu. Yorgunsa enerjiyi, sıkıcıysa oyunlaştırmayı, zorsa en kolay parçadan başlamayı, dikkat dağınıksa ortamı hazırlamayı öner.`,
    user({ text: `Görev: ${task.label}` }),
    STEPS_SCHEMA,
    0.7
  );
}

// ---------- AI ile haftalık plan ----------
const PLAN_SCHEMA = {
  type: 'OBJECT',
  properties: {
    days: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          day: { type: 'INTEGER', description: '0=Pazar, 1=Pazartesi ... 6=Cumartesi' },
          tasks: {
            type: 'ARRAY',
            items: {
              type: 'OBJECT',
              properties: {
                label: { type: 'STRING' },
                time: { type: 'STRING', description: 'HH:MM 24 saat ya da boş' },
                xp: { type: 'INTEGER' },
                required: { type: 'BOOLEAN' },
                cue: { type: 'STRING', description: '"Eğer ... o zaman ..." biçiminde kısa başlama planı' },
              },
              required: ['label', 'xp', 'required'],
            },
          },
        },
        required: ['day', 'tasks'],
      },
    },
  },
  required: ['days'],
};

export async function generatePlan(description) {
  const ctx = buildContext(useStore.getState());
  const out = await json(
    `${PERSONA(ctx)}

GÖREV: Öğrencinin anlattığı duruma göre gerçekçi bir HAFTALIK çalışma planı üret.
Kurallar: günde en fazla 3-4 görev; zorunlu (required) görev günde 1-3 tane, gerisi isteğe bağlı; haftada en az 1 gün tamamen görevsiz dinlenme günü bırak (tasks boş dizi); görevler somut ve ölçülebilir olsun ("Matematik: 30 soru", "Fizik: Elektrik konu tekrarı 40 dk"); xp görev süresine göre 10-60; time varsa HH:MM, bilmiyorsan boş string; her zorunlu göreve "Eğer ... o zaman ..." biçiminde kısa bir cue yaz. Öğrencinin belirttiği müsaitlik ve derslere uy; 7 günün hepsini döndür.`,
    user({ text: description }),
    PLAN_SCHEMA,
    0.5
  );
  const plan = {};
  for (let d = 0; d < 7; d++) plan[d] = [];
  (out.days || []).forEach((day) => {
    if (day.day < 0 || day.day > 6) return;
    plan[day.day] = (day.tasks || [])
      .filter((t) => t.label?.trim())
      .map((t, i) => ({
        id: `ai-${day.day}-${i}-${Date.now()}`,
        label: t.label.trim(),
        time: /^\d{2}:\d{2}$/.test(t.time || '') ? t.time : '',
        xp: Math.max(5, Math.min(100, Math.round(t.xp) || 20)),
        required: !!t.required,
        cue: t.cue || '',
      }));
  });
  return plan;
}

import { create } from 'zustand';
import { todayKey, addDays } from '../logic/dates';
import { isDayComplete, isDayCovered } from '../logic/streak';
import { SHOP } from '../data/shop';
import { nextState } from '../logic/leitner';
import { XP_BLOCK, XP_CARD, XP_EXAM, XP_DEEP, XP_START, XP_PACT, FEYNMAN_DAILY_CAP } from '../data/levels';
import { getPresets } from '../data/presets';
import { setLang as setI18n, detectLang } from '../i18n';

export const PERSIST = ['xp', 'days', 'blocks', 'exams', 'cardState', 'customCards', 'spent', 'inventory', 'frozen', 'feynman', 'profile', 'plan', 'subjects', 'seedCards', 'stats', 'pacts', 'prefs', 'chests', 'lang'];

async function loadRaw() {
  if (window.api) return window.api.load();
  try {
    return JSON.parse(localStorage.getItem('mq-data'));
  } catch {
    return null;
  }
}

function saveRaw(data) {
  if (window.api) window.api.save(data);
  else localStorage.setItem('mq-data', JSON.stringify(data));
}

const addXp = (xp, n) => Math.max(0, xp + n);

export const useStore = create((set, get) => ({
  hydrated: false,
  xp: 0,
  days: {}, // { 'YYYY-MM-DD': { done: [taskId] } }
  blocks: {}, // { 'YYYY-MM-DD': tamamlanan 45+5 blok sayısı }
  exams: [], // { id, date, subject, correct, wrong, net }
  cardState: {}, // { cardId: { box, next } }
  customCards: [],
  spent: 0, // Mağaza'da harcanan XP (seviye toplam XP'den hesaplanır, harcama seviyeyi düşürmez)
  inventory: {}, // { freeze: 1 }
  frozen: {}, // { 'YYYY-MM-DD': true } Seri Dondurma ile korunan günler
  feynman: {}, // { 'YYYY-MM-DD': XP verilen anlatım sayısı }
  profile: null, // { name, grade, exam, goal, reward } — null ise kurulum sihirbazı açılır
  plan: {}, // { 0..6: [{ id, label, time, xp, required, cue }] }  (0 = Pazar)
  subjects: [], // deneme dersleri: { key, exam?, name, target, max, wrongDiv? }
  seedCards: false,
  stats: {}, // { 'YYYY-MM-DD': { starts, postpones } }
  pacts: {}, // { 'YYYY-MM-DD': { paid } } günlük söz
  lang: null, // 'tr' | 'en' ... null ise ilk açılışta dil sorulur
  chests: {}, // { 'YYYY-MM-DD': true } açılan günlük sandıklar
  prefs: { reminders: false, guard: true, guardTime: '21:00', sound: true, theme: 'auto' },

  hydrate: async () => {
    const saved = await loadRaw();
    const patch = {};
    if (saved) PERSIST.forEach((k) => saved[k] !== undefined && (patch[k] = saved[k]));
    // Eski sürümden gelen kullanıcı (profil yok ama XP var): YKS planıyla devam etsin.
    if (saved && !saved.profile && saved.xp > 0) {
      const y = getPresets().yks;
      Object.assign(patch, { profile: { name: '', grade: '10. sınıf', exam: 'YKS', goal: '', reward: '' }, plan: y.plan, subjects: y.subjects, seedCards: true });
    }
    // Dil: kayıtlıysa onu kullan; eski kullanıcı (profil var, dil yok) Türkçe kalır; yenide sihirbaz sorar
    if (!patch.lang && patch.profile) patch.lang = 'tr';
    setI18n(patch.lang || detectLang());
    set({ ...patch, prefs: { ...get().prefs, ...(patch.prefs || {}) }, hydrated: true });
    get().applyFreeze();
  },

  // Dün tamamlanmadıysa ama önceki gün seri canlıysa: koruyucu varsa otomatik harca.
  applyFreeze: () => {
    const { days, frozen, inventory, plan } = get();
    const y = addDays(todayKey(), -1);
    const before = addDays(y, -1);
    const alive = isDayComplete(days, before, plan) || frozen[before];
    if (isDayCovered(days, frozen, y, plan) || !alive || !(inventory.freeze > 0)) return;
    set({ frozen: { ...frozen, [y]: true }, inventory: { ...inventory, freeze: inventory.freeze - 1 } });
  },

  award: (n) => set({ xp: addXp(get().xp, n) }),

  addCards: (cards) => {
    const t = Date.now();
    set({ customCards: [...get().customCards, ...cards.map((c, i) => ({ ...c, id: `u-${t}-${i}` }))] });
  },

  // Feynman XP'si günlük limitli. Verilen XP'yi (0 olabilir) döndürür.
  claimFeynman: (xp) => {
    const { feynman } = get();
    const key = todayKey();
    const used = feynman[key] || 0;
    if (!xp || used >= FEYNMAN_DAILY_CAP) return 0;
    set({ feynman: { ...feynman, [key]: used + 1 }, xp: addXp(get().xp, xp) });
    return xp;
  },

  buyItem: (id) => {
    const item = SHOP.find((i) => i.id === id);
    const { xp, spent, inventory } = get();
    if (!item || xp - spent < item.cost || (inventory[id] || 0) >= item.max) return false;
    set({ spent: spent + item.cost, inventory: { ...inventory, [id]: (inventory[id] || 0) + 1 } });
    return true;
  },

  toggleTask: (dateKey, task) => {
    const { days, xp, plan, pacts } = get();
    const done = days[dateKey]?.done || [];
    const isDone = done.includes(task.id);
    const nextDone = isDone ? done.filter((id) => id !== task.id) : [...done, task.id];
    const nextDays = { ...days, [dateKey]: { done: nextDone } };
    let bonus = 0;
    let nextPacts = pacts;
    // Yumuşak taahhüt: söz verilmiş gün tamamlanırsa bir kez bonus
    if (!isDone && pacts[dateKey] && !pacts[dateKey].paid && isDayComplete(nextDays, dateKey, plan)) {
      bonus = XP_PACT;
      nextPacts = { ...pacts, [dateKey]: { paid: true } };
    }
    set({ days: nextDays, pacts: nextPacts, xp: addXp(xp, (isDone ? -task.xp : task.xp) + bonus) });
  },

  signPact: (dateKey) => set({ pacts: { ...get().pacts, [dateKey]: { paid: false } } }),

  // kind: 'starts' | 'postpones'. Başlama XP'si günde 3 ile sınırlı (kötüye kullanımı önler).
  logStat: (kind) => {
    const { stats, xp } = get();
    const key = todayKey();
    const cur = stats[key] || { starts: 0, postpones: 0 };
    const reward = kind === 'starts' && cur.starts < 3 ? XP_START : 0;
    set({ stats: { ...stats, [key]: { ...cur, [kind]: cur[kind] + 1 } }, xp: addXp(xp, reward) });
    return reward;
  },

  // Günlük sandık: zorunlu görevler bitince günde bir kez açılır. Ödül sürpriz: 20-60 XP, nadiren Seri Dondurma.
  openChest: () => {
    const { chests, plan, days, inventory, xp } = get();
    const key = todayKey();
    if (chests[key] || !isDayComplete(days, key, plan)) return null;
    const max = SHOP.find((i) => i.id === 'freeze').max;
    let reward;
    if (Math.random() < 0.05 && (inventory.freeze || 0) < max) {
      reward = { type: 'freeze' };
      set({ inventory: { ...inventory, freeze: (inventory.freeze || 0) + 1 } });
    } else {
      reward = { type: 'xp', amount: 20 + 10 * Math.floor(Math.random() * 5) };
      set({ xp: addXp(xp, reward.amount) });
    }
    set({ chests: { ...get().chests, [key]: true } });
    return reward;
  },

  setLang: (lang) => { setI18n(lang); set({ lang }); },
  setProfile: (profile) => set({ profile }),
  setPrefs: (p) => set({ prefs: { ...get().prefs, ...p } }),
  setPlan: (plan) => set({ plan }),
  setDayTasks: (dow, tasks) => set({ plan: { ...get().plan, [dow]: tasks } }),
  applyPreset: (id) => {
    const p = getPresets()[id];
    set({ plan: p.plan, subjects: p.subjects, seedCards: p.seedCards });
  },
  addSubject: (sub) => set({ subjects: [...get().subjects, { ...sub, key: `s-${Date.now()}` }] }),
  deleteSubject: (key) => set({ subjects: get().subjects.filter((x) => x.key !== key) }),

  addBlock: (deep = false) => {
    const { blocks, xp } = get();
    const key = todayKey();
    set({ blocks: { ...blocks, [key]: (blocks[key] || 0) + 1 }, xp: addXp(xp, XP_BLOCK + (deep ? XP_DEEP : 0)) });
  },

  addExam: (exam) => {
    const { exams, xp } = get();
    set({ exams: [...exams, { ...exam, id: Date.now() }], xp: addXp(xp, XP_EXAM) });
  },

  deleteExam: (id) => {
    const { exams, xp } = get();
    set({ exams: exams.filter((e) => e.id !== id), xp: addXp(xp, -XP_EXAM) });
  },

  reviewCard: (cardId, correct) => {
    const { cardState, xp } = get();
    set({
      cardState: { ...cardState, [cardId]: nextState(cardState[cardId], correct, todayKey()) },
      xp: addXp(xp, correct ? XP_CARD : 0),
    });
  },

  addCard: (card) => {
    const { customCards } = get();
    set({ customCards: [...customCards, { ...card, id: `u-${Date.now()}` }] });
  },
}));

// Her değişiklikte (kısa gecikmeyle) diske yaz
let timer = null;
useStore.subscribe((state) => {
  if (!state.hydrated) return;
  clearTimeout(timer);
  timer = setTimeout(() => {
    const out = {};
    PERSIST.forEach((k) => (out[k] = state[k]));
    saveRaw(out);
  }, 300);
});

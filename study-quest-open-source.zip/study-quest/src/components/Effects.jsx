import { useEffect, useState } from 'react';
import { useT } from '../i18n/useT';
import Mascot from './Mascot';

// Uçan "+XP" yazıları ve tam ekran kutlama (seviye, seri, sandık). Olaylar logic/fx.js'ten gelir.
export default function Effects() {
  const t = useT();
  const [floats, setFloats] = useState([]);
  const [queue, setQueue] = useState([]);

  useEffect(() => {
    const xp = (e) => {
      const id = Math.random();
      setFloats((f) => [...f, { id, t: `+${e.detail.delta} XP` }]);
      setTimeout(() => setFloats((f) => f.filter((x) => x.id !== id)), 1500);
    };
    const cel = (e) => setQueue((q) => [...q, e.detail]);
    window.addEventListener('mq-xp', xp);
    window.addEventListener('mq-celebrate', cel);
    return () => {
      window.removeEventListener('mq-xp', xp);
      window.removeEventListener('mq-celebrate', cel);
    };
  }, []);

  const c = queue[0];
  return (
    <>
      <div className="xp-floats">{floats.map((f) => <div key={f.id} className="xp-float">{f.t}</div>)}</div>
      {c && (
        <div className="modal-bg celebrate" onClick={() => setQueue((q) => q.slice(1))}>
          <div className="cel-card" onClick={(e) => e.stopPropagation()}>
            <Mascot mood="cheer" size={170} />
            <div className="cel-emoji">{c.emoji}</div>
            <h2>{c.title}</h2>
            <p>{c.text}</p>
            <button className="btn primary big" onClick={() => setQueue((q) => q.slice(1))}>{t('Devam')}</button>
          </div>
        </div>
      )}
    </>
  );
}

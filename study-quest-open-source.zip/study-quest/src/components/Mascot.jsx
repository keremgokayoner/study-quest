// Bolt: yeşil şimşek antenli maskot. mood: happy | cheer | focus | sleepy | think
export default function Mascot({ mood = 'happy', size = 100 }) {
  const sleepy = mood === 'sleepy';
  const mouth = {
    happy: <path d="M48 80 Q60 92 72 80" stroke="#2b6b00" strokeWidth="4" fill="none" strokeLinecap="round" />,
    cheer: (<><path d="M46 78 Q60 102 74 78 Z" fill="#7a2b2b" stroke="#2b6b00" strokeWidth="3" strokeLinejoin="round" /><ellipse cx="60" cy="90" rx="7" ry="4" fill="#ff7a8a" /></>),
    focus: <path d="M52 83 L68 83" stroke="#2b6b00" strokeWidth="4" strokeLinecap="round" />,
    sleepy: <path d="M54 83 Q60 86 66 83" stroke="#2b6b00" strokeWidth="4" fill="none" strokeLinecap="round" />,
    think: <circle cx="66" cy="83" r="4" fill="#2b6b00" />,
  }[mood] || null;

  return (
    <svg className={`mascot ${mood}`} width={size} height={size} viewBox="0 0 120 120" aria-hidden="true">
      <polygon points="62,2 50,22 59,22 54,36 72,14 62,14" fill="#ffc800" stroke="#e5a800" strokeWidth="2" strokeLinejoin="round" />
      {mood === 'cheer' && (<><ellipse className="arm l" cx="14" cy="58" rx="9" ry="14" fill="#58cc02" stroke="#46a302" strokeWidth="3" /><ellipse className="arm r" cx="106" cy="58" rx="9" ry="14" fill="#58cc02" stroke="#46a302" strokeWidth="3" /></>)}
      <ellipse cx="60" cy="74" rx="44" ry="40" fill="#58cc02" stroke="#46a302" strokeWidth="4" />
      <ellipse cx="60" cy="88" rx="28" ry="20" fill="#89e219" />
      {sleepy ? (
        <g stroke="#2b6b00" strokeWidth="4" strokeLinecap="round"><path d="M34 64 Q44 70 54 64" fill="none" /><path d="M66 64 Q76 70 86 64" fill="none" /></g>
      ) : (
        <g className="eyes">
          <circle cx="44" cy="62" r="12" fill="#fff" stroke="#dfe6dc" strokeWidth="2" />
          <circle cx="76" cy="62" r="12" fill="#fff" stroke="#dfe6dc" strokeWidth="2" />
          <circle className="pupil" cx={mood === 'think' ? 49 : 46} cy={mood === 'think' ? 58 : 64} r="5.5" fill="#222" />
          <circle className="pupil" cx={mood === 'think' ? 81 : 74} cy={mood === 'think' ? 58 : 64} r="5.5" fill="#222" />
        </g>
      )}
      {mood === 'focus' && <g stroke="#2b6b00" strokeWidth="4" strokeLinecap="round"><path d="M32 48 L54 54" /><path d="M88 48 L66 54" /></g>}
      {mouth}
      {sleepy && <text className="zzz" x="92" y="30" fontSize="20" fontWeight="900" fill="#1cb0f6">z</text>}
      {mood === 'cheer' && <text className="spark" x="4" y="20" fontSize="18">✨</text>}
    </svg>
  );
}

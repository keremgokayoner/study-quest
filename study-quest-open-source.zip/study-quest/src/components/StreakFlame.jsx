import { useStore } from '../store/useStore';
import { useT } from '../i18n/useT';
import { computeStreak, isDayComplete, requiredIds } from '../logic/streak';
import { todayKey } from '../logic/dates';
import { MILESTONES } from '../logic/fx';
import { useNow } from '../hooks/useNow';

export default function StreakFlame() {
  const t = useT();
  const days = useStore((s) => s.days);
  const frozen = useStore((s) => s.frozen);
  const plan = useStore((s) => s.plan);
  const now = useNow();
  const key = todayKey();
  const streak = computeStreak(days, key, frozen, plan);
  // Kayıp korkusu: akşam saatlerinde bugün hâlâ bitmemişse alev uyarı rengine döner
  const risk = streak > 0 && now.getHours() >= 18 && requiredIds(plan, key).length > 0 && !isDayComplete(days, key, plan);
  const next = MILESTONES.find((m) => m > streak);

  return (
    <div className={`streak ${streak > 0 ? 'on' : ''} ${risk ? 'risk' : ''}`}>
      <span className="flame">🔥</span>
      <span className="streak-n" key={streak}>{streak}</span>
      <span className="streak-l">{t('gün seri')}</span>
      {risk ? <div className="streak-sub">{t('⚠️ Bugün tamamla, serin risk altında')}</div>
        : streak > 0 && next ? <div className="streak-sub">{t('{n}. güne {d} gün kaldı', { n: next, d: next - streak })}</div> : null}
    </div>
  );
}

import { useStore } from '../store/useStore';
import { useT } from '../i18n/useT';
import { levelInfo } from '../data/levels';

export default function XPBar() {
  const t = useT();
  const xp = useStore((s) => s.xp);
  const goal = useStore((s) => s.profile?.goal);
  const { level, into, need, title } = levelInfo(xp, goal);
  const pct = Math.min(100, Math.round((into / need) * 100));

  return (
    <div className={`xpbar ${pct >= 80 ? 'near' : ''}`}>
      <div className="xp-head">
        <div className="lvl-badge" key={level}>{level}</div>
        <div>
          <div className="xp-title">{title}</div>
          <div className="xp-level">{t('Seviye {n}', { n: level })}</div>
        </div>
      </div>
      <div className="bar"><div className="bar-fill" style={{ width: `${Math.max(pct, 4)}%` }} /></div>
      <div className="xp-nums">{pct >= 80 ? t('⚡ Seviye atlamaya {n} XP kaldı!', { n: need - into }) : `${into} / ${need} XP`}</div>
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { microSteps } from '../services/ai';
import { beep } from '../logic/ambient';

const go = (tab) => window.dispatchEvent(new CustomEvent('mq-nav', { detail: tab }));
const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

function Modal({ children, onClose }) {
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>{children}</div>
    </div>
  );
}

// "Sadece 2 dakika" kuralı: başlamak en zor kısım, sonrası genelde kolaylaşır.
export function Starter({ task, onClose }) {
  const t = useT();
  const logStat = useStore((s) => s.logStat);
  const [left, setLeft] = useState(120);
  const [reward, setReward] = useState(null);
  const endRef = useRef(Date.now() + 120000);

  useEffect(() => { setReward(logStat('starts')); }, [logStat]);
  useEffect(() => {
    if (left <= 0) return;
    const id = setInterval(() => {
      const r = Math.max(0, Math.ceil((endRef.current - Date.now()) / 1000));
      setLeft(r);
      if (r === 0) beep(880);
    }, 250);
    return () => clearInterval(id);
  }, [left]);

  return (
    <Modal onClose={onClose}>
      <h3>{task.label}</h3>
      {task.cue && <p className="muted small">🔗 {task.cue}</p>}
      {left > 0 ? (
        <>
          <div className="timer-time">{fmt(left)}</div>
          <p className="muted">{t('Sadece {time} boyunca başla. Mükemmel olmak zorunda değil, sadece başla.', { time: fmt(left) })}</p>
          {reward > 0 && <p className="ok">{t('+{n} XP başlama ödülü!', { n: reward })}</p>}
          <button className="btn" onClick={onClose}>{t('Vazgeç')}</button>
        </>
      ) : (
        <>
          <p className="ok big-msg">{t('🎉 En zor kısmı geçtin! Devam edelim mi?')}</p>
          <div className="controls">
            <button className="btn primary" onClick={() => { onClose(); go('focus'); }}>{t('⏱️ 45 dk odak bloğu başlat')}</button>
            <button className="btn" onClick={onClose}>{t('Şimdilik bu kadar')}</button>
          </div>
        </>
      )}
    </Modal>
  );
}

const REASONS = ['😴 Yorgunum', '🥱 Sıkıcı geliyor', '🧱 Çok zor / nereden başlayacağımı bilmiyorum', '📱 Dikkatim dağınık', '⏰ Vaktim yok gibi hissediyorum'];
const FALLBACK = {
  starter: 'Kitabı/defteri aç ve sadece ilk 2 dakika ilk soruya ya da başlığa bak.',
  steps: ['Masanı ve telefonunu hazırla (1 dk)', 'Görevin en kolay parçasını seç, 5 dk çalış', '5 dk sonra devam edip etmeyeceğine karar ver'],
  note: 'Başlamak en zor kısım; başlayınca çoğu zaman kolaylaşır.',
};

// Erteleme engelleyici: ceza yok, sürtünme var. Önce neden, sonra küçük adım, sonra (istersen) ertele.
export function Postpone({ task, onClose, onStart }) {
  const t = useT();
  const logStat = useStore((s) => s.logStat);
  const freeze = useStore((s) => s.inventory.freeze || 0);
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);
  const [offline, setOffline] = useState(false);
  const [giveUp, setGiveUp] = useState(false);

  const pick = async (reason) => {
    setBusy(true);
    try { setRes(await microSteps(task, reason)); }
    catch { setRes({ starter: t(FALLBACK.starter), steps: FALLBACK.steps.map((x) => t(x)), note: t(FALLBACK.note) }); setOffline(true); }
    finally { setBusy(false); }
  };
  const postpone = () => { logStat('postpones'); setGiveUp(true); };

  return (
    <Modal onClose={onClose}>
      <h3>{t('⏸️ "{task}" — ertelemeden önce 30 saniye', { task: task.label })}</h3>
      {giveUp ? (
        <>
          <p>{t('Tamam, anlıyorum. Bunu kaydettim; yarın yakalarız.')}</p>
          {task.required && <p className="muted small">{t('Bu zorunlu bir görev, bugün bitmezse seri riski var.')}{freeze > 0 ? ' ' + t('(ama {n} Seri Dondurma koruyucun hazır 🧊)', { n: freeze }) : ''}</p>}
          <button className="btn" onClick={onClose}>{t('Kapat')}</button>
        </>
      ) : !res ? (
        <>
          <p className="muted">{t('Neden ertelemek istiyorsun? (Doğru cevap yok, sadece küçük bir adım bulalım.)')}</p>
          <div className="reasons">
            {REASONS.map((r) => <button key={r} className="btn" disabled={busy} onClick={() => pick(r)}>{t(r)}</button>)}
          </div>
          {busy && <p className="muted">{t('Bolt küçük adımları hazırlıyor…')}</p>}
        </>
      ) : (
        <>
          <p className="ok"><b>{t('İlk 2 dakika:')}</b> {res.starter}</p>
          <ol>{res.steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
          <p className="muted">{res.note}</p>
          {offline && <p className="muted small">{t("(AI kapalı, genel öneri gösteriliyor. Ayarlar'dan Gemini anahtarı eklersen göreve özel adımlar gelir.)")}</p>}
          <div className="controls">
            <button className="btn primary" onClick={() => { onClose(); onStart(); }}>{t('▶ 2 dk başla')}</button>
            <button className="btn" onClick={postpone}>{t('Yine de ertele')}</button>
          </div>
        </>
      )}
    </Modal>
  );
}

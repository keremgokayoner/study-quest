import { useStore } from '../store/useStore';
import { useT } from '../i18n/useT';
import { addDays, dayOfWeek, todayKey } from '../logic/dates';
import { isDayComplete, isRestDay } from '../logic/streak';

const LABELS = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

// Oyunlaştırılmış hafta şeridi: bu haftanın 7 günü, tamamlananlar alevli, dondurulanlar buzlu.
export default function WeekStrip() {
  const t = useT();
  const days = useStore((s) => s.days);
  const plan = useStore((s) => s.plan);
  const frozen = useStore((s) => s.frozen);
  const today = todayKey();
  const monday = addDays(today, -((dayOfWeek(today) + 6) % 7));

  return (
    <div className="week">
      {LABELS.map((l, i) => {
        const k = addDays(monday, i);
        const done = isDayComplete(days, k, plan);
        const ice = !done && frozen[k];
        const rest = !done && !ice && isRestDay(plan, k);
        const future = k > today;
        const cls = done ? 'done' : ice ? 'ice' : rest ? 'rest' : future ? 'future' : k === today ? '' : 'missed';
        return (
          <div key={k} className={`day ${cls} ${k === today ? 'today' : ''}`}>
            <div className="day-l">{t(l)}</div>
            <div className="day-dot">{done ? '🔥' : ice ? '🧊' : rest ? '😴' : ''}</div>
          </div>
        );
      })}
    </div>
  );
}

import { useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { subjectLabel } from '../data/targets';
import { todayKey } from '../logic/dates';
import { XP_EXAM } from '../data/levels';

const round2 = (n) => Math.round(n * 100) / 100;

export default function Exams() {
  const t = useT();
  const exams = useStore((s) => s.exams);
  const addExam = useStore((s) => s.addExam);
  const deleteExam = useStore((s) => s.deleteExam);
  const SUBJECTS = useStore((s) => s.subjects);
  const addSubject = useStore((s) => s.addSubject);
  const deleteSubject = useStore((s) => s.deleteSubject);
  const [sf, setSf] = useState({ name: '', max: 40, target: 20, wrongDiv: 4 });

  const [form, setForm] = useState({ subject: SUBJECTS[0]?.key || '', date: todayKey(), correct: '', wrong: '' });
  const [error, setError] = useState('');

  const subj = SUBJECTS.find((s) => s.key === form.subject) || SUBJECTS[0];
  const correct = Number(form.correct) || 0;
  const wrong = Number(form.wrong) || 0;
  const div = subj?.wrongDiv ?? 4;
  const net = round2(correct - (div ? wrong / div : 0));

  const submit = (e) => {
    e.preventDefault();
    if (!Number.isInteger(correct) || !Number.isInteger(wrong) || correct < 0 || wrong < 0) {
      setError(t('Doğru ve yanlış sayıları 0 veya daha büyük tam sayı olmalı.'));
      return;
    }
    if (!subj) {
      setError(t('Önce aşağıdan bir ders ekle.'));
      return;
    }
    if (correct + wrong > subj.max) {
      setError(t('{name} testinde en fazla {n} soru var.', { name: subjectLabel(subj), n: subj.max }));
      return;
    }
    setError('');
    addExam({ subject: subj.key, date: form.date, correct, wrong, net });
    setForm({ ...form, correct: '', wrong: '' });
  };

  const sorted = [...exams].sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);

  return (
    <div>
      <h2>{t('Deneme Sonucu Gir')}</h2>

      <form className="exam-form" onSubmit={submit}>
        <select value={subj?.key ?? ''} onChange={(e) => setForm({ ...form, subject: e.target.value })}>
          {SUBJECTS.map((s) => (
            <option key={s.key} value={s.key}>
              {subjectLabel(s)} ({t('hedef {n}', { n: s.target })})
            </option>
          ))}
        </select>
        <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
        <input type="number" min="0" placeholder={t('Doğru')} value={form.correct} onChange={(e) => setForm({ ...form, correct: e.target.value })} />
        <input type="number" min="0" placeholder={t('Yanlış')} value={form.wrong} onChange={(e) => setForm({ ...form, wrong: e.target.value })} />
        <div className="net-preview">{t('Net:')} <b>{net}</b></div>
        <button className="btn primary" type="submit">{t('Kaydet (+{n} XP)', { n: XP_EXAM })}</button>
      </form>
      {error && <div className="error">{error}</div>}
      <p className="muted small">{t('Net = doğru − yanlış / katsayı (YKS: 4, LGS: 3; her ders için ayarlanabilir).')}</p>

      <h3>{t('Dersler ve hedef netler')}</h3>
      <ul className="mini-list">
        {SUBJECTS.map((s) => (
          <li key={s.key}>{subjectLabel(s)} · {t('{n} soru · hedef {target}', { n: s.max, target: s.target })} <button className="link" onClick={() => deleteSubject(s.key)}>{t('sil')}</button></li>
        ))}
      </ul>
      <div className="exam-form">
        <input placeholder={t('Ders / test adı')} value={sf.name} onChange={(e) => setSf({ ...sf, name: e.target.value })} />
        <input type="number" min="1" title={t('Soru sayısı')} value={sf.max} onChange={(e) => setSf({ ...sf, max: Number(e.target.value) })} />
        <input type="number" min="0" step="0.25" title={t('Hedef net')} value={sf.target} onChange={(e) => setSf({ ...sf, target: Number(e.target.value) })} />
        <select value={sf.wrongDiv} onChange={(e) => setSf({ ...sf, wrongDiv: Number(e.target.value) })}>
          <option value={4}>{t('4 yanlış = 1 doğru')}</option>
          <option value={3}>{t('3 yanlış = 1 doğru')}</option>
          <option value={0}>{t('Yanlış etkilemez')}</option>
        </select>
        <button className="btn" onClick={() => { if (sf.name.trim() && sf.max > 0) { addSubject({ ...sf, name: sf.name.trim() }); setSf({ ...sf, name: '' }); } }}>{t('Ders ekle')}</button>
      </div>

      <h3>{t('Geçmiş denemeler')}</h3>
      {sorted.length === 0 ? (
        <p className="muted">{t('Henüz deneme yok. İlk sonucunu gir, pano dolsun.')}</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>{t('Deneme tarihi')}</th>
              <th>{t('Ders')}</th>
              <th>{t('D')}</th>
              <th>{t('Y')}</th>
              <th>{t('Net')}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((e) => {
              const s = SUBJECTS.find((x) => x.key === e.subject);
              return (
                <tr key={e.id}>
                  <td>{e.date}</td>
                  <td>{s ? subjectLabel(s) : e.subject}</td>
                  <td>{e.correct}</td>
                  <td>{e.wrong}</td>
                  <td><b>{e.net}</b></td>
                  <td>
                    <button className="link" onClick={() => deleteExam(e.id)}>{t('sil')}</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

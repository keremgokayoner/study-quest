import { useStore } from '../store/useStore';
import { LANGS } from '../i18n';
import { useT } from '../i18n/useT';

// Dil sekmesi: arayüz ve Bolt'un (AI) cevap dili birlikte değişir.
export default function Language() {
  const t = useT();
  const lang = useStore((s) => s.lang) || 'tr';
  const setLang = useStore((s) => s.setLang);

  return (
    <div>
      <h2>{t('Dil')}</h2>
      <p className="muted">{t('Arayüz dili ve Bolt\'un cevap dili birlikte değişir. Planındaki görev adları senin yazdığın dilde kalır.')}</p>
      <div className="presets">
        {LANGS.map((l) => (
          <button key={l.id} className={`preset ${lang === l.id ? 'on' : ''}`} onClick={() => setLang(l.id)}>
            <b>{l.flag} {l.name}</b>
            {lang === l.id && <span className="muted small">✓ {t('Seçili')}</span>}
          </button>
        ))}
      </div>
      <p className="muted small">{t('Başka bir dil mi lazım? Dil dosyası eklemek çok kolay (README\'ye bak).')}</p>
    </div>
  );
}

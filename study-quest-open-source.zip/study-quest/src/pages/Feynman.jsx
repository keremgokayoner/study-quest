import { useEffect, useRef, useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { evaluateFeynman, toWav, blobToBase64 } from '../services/ai';
import { feynmanXp, FEYNMAN_DAILY_CAP } from '../data/levels';
import { todayKey } from '../logic/dates';

const MAX_SEC = 300;
const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

export default function Feynman() {
  const t = useT();
  const claimFeynman = useStore((s) => s.claimFeynman);
  const usedToday = useStore((s) => s.feynman[todayKey()] || 0);
  const [topic, setTopic] = useState('');
  const [text, setText] = useState('');
  const [rec, setRec] = useState(false);
  const [sec, setSec] = useState(0);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [result, setResult] = useState(null);
  const mr = useRef(null);
  const chunks = useRef([]);
  const timer = useRef(null);

  useEffect(() => () => { clearInterval(timer.current); mr.current?.stream?.getTracks().forEach((t) => t.stop()); }, []);

  const finish = async (input) => {
    setBusy(true); setErr(''); setResult(null);
    try {
      const out = await evaluateFeynman({ topic, ...input });
      const gained = claimFeynman(feynmanXp(out.score));
      setResult({ ...out, gained, capped: feynmanXp(out.score) > 0 && gained === 0 });
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const start = async () => {
    setErr('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const r = new MediaRecorder(stream);
      chunks.current = [];
      r.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      r.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        try {
          const wav = await toWav(new Blob(chunks.current));
          await finish({ audioBase64: await blobToBase64(wav) });
        } catch (e) {
          setErr(e.message || t('Ses işlenemedi.'));
        }
      };
      mr.current = r;
      r.start();
      setRec(true); setSec(0);
      timer.current = setInterval(() => setSec((s) => { if (s + 1 >= MAX_SEC) stop(); return s + 1; }), 1000);
    } catch {
      setErr(t('Mikrofona erişilemedi. İzin verdiğinden ve mikrofonun bağlı olduğundan emin ol; olmazsa aşağıdan yazarak anlat.'));
    }
  };

  const stop = () => {
    clearInterval(timer.current);
    setRec(false);
    if (mr.current?.state === 'recording') mr.current.stop();
  };

  return (
    <div>
      <h2>{t('Feynman Anlatımı')}</h2>
      <p className="muted">
        {t('Bugün çalıştığın konuyu 12 yaşında bir çocuğa anlatır gibi, kendi cümlelerinle anlat. Başarılı anlatım +150 XP (80+ puan: +25, 90+: +50). Günde en fazla {cap} anlatım XP verir ({used}/{cap} kullanıldı).', { cap: FEYNMAN_DAILY_CAP, used: usedToday })}
      </p>
      <input className="wide" placeholder={t('Konu (örn. Ohm yasası ve seri-paralel bağlama)')} value={topic} onChange={(e) => setTopic(e.target.value)} />

      <div className="controls">
        {rec ? (
          <button className="btn rec" onClick={stop}>{t('⏹ Bitir ve değerlendir')} · {fmt(sec)}</button>
        ) : (
          <button className="btn primary" onClick={start} disabled={busy}>{t('🎙️ Anlatmaya başla')}</button>
        )}
        <span className="muted small">{t("En fazla {time} · ses Gemini'ye gönderilir ve yazıya da dökülür", { time: fmt(MAX_SEC) })}</span>
      </div>

      <details>
        <summary className="muted">{t('Mikrofon yok mu? Yazarak anlat')}</summary>
        <textarea className="wide" rows={6} value={text} onChange={(e) => setText(e.target.value)} placeholder={t('Anlatımını buraya yaz…')} />
        <button className="btn" disabled={busy || text.trim().length < 20} onClick={() => finish({ text })}>{t('Yazıyı değerlendir')}</button>
      </details>

      {busy && <p className="muted">{t('Bolt dinliyor ve değerlendiriyor…')}</p>}
      {err && <div className="error">{err}</div>}

      {result && (
        <div className="panel">
          <div className="score">{result.score}<span className="muted">/100</span></div>
          {result.gained > 0 && <div className="banner ok">{t('+{n} XP kazandın!', { n: result.gained })}</div>}
          {result.capped && <div className="banner">{t('Bugünkü ödüllü anlatım hakkın doldu; yine de geri bildirim senin için 👇')}</div>}
          {result.score < 60 && <div className="banner">{t('60 puanın altı XP vermez. Eksikleri tamamlayıp yeniden anlat!')}</div>}
          <p className="pre">{result.feedback}</p>
          {result.praise.length > 0 && (<><h3>{t('✅ Doğru anlaşılanlar')}</h3><ul>{result.praise.map((x, i) => <li key={i}>{x}</li>)}</ul></>)}
          {result.missing.length > 0 && (<><h3>{t('🧩 Eksikler')}</h3><ul>{result.missing.map((x, i) => <li key={i}>{x}</li>)}</ul></>)}
          {result.corrections.length > 0 && (<><h3>{t('🛠️ Düzeltmeler')}</h3><ul>{result.corrections.map((x, i) => <li key={i}>{x}</li>)}</ul></>)}
          <details><summary className="muted">{t('Yazıya dökülen anlatımın')}</summary><p className="pre muted">{result.transcript}</p></details>
        </div>
      )}
    </div>
  );
}

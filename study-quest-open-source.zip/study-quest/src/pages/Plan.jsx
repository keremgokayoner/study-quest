import { useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { dayName, dayShort } from '../data/schedule';
import { getPresets } from '../data/presets';
import { generatePlan } from '../services/ai';

const ORDER = [1, 2, 3, 4, 5, 6, 0];
const newTask = () => ({ id: `t-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, label: '', time: '', xp: 20, required: true, cue: '' });

export default function Plan() {
  const t = useT();
  const PRESETS = getPresets();
  const plan = useStore((s) => s.plan);
  const setDayTasks = useStore((s) => s.setDayTasks);
  const setPlan = useStore((s) => s.setPlan);
  const applyPreset = useStore((s) => s.applyPreset);
  const [day, setDay] = useState(new Date().getDay());
  const [desc, setDesc] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const tasks = plan[day] || [];
  const update = (i, patch) => setDayTasks(day, tasks.map((t, k) => (k === i ? { ...t, ...patch } : t)));
  const remove = (i) => setDayTasks(day, tasks.filter((_, k) => k !== i));

  const copyTo = (targets) => {
    const next = { ...plan };
    targets.filter((d) => d !== day).forEach((d) => {
      next[d] = tasks.map((t, i) => ({ ...t, id: `t-${Date.now()}-${d}-${i}` }));
    });
    setPlan(next);
  };

  const ai = async () => {
    if (!desc.trim() || busy) return;
    if (Object.values(plan).some((x) => x.length) && !confirm(t('Mevcut planın AI planıyla değiştirilecek. Devam?'))) return;
    setBusy(true); setErr('');
    try { setPlan(await generatePlan(desc)); } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };

  const loadPreset = (id) => {
    if (id && confirm(t('"{name}" şablonu mevcut planının yerine geçecek. Devam?', { name: PRESETS[id].name }))) applyPreset(id);
  };

  return (
    <div>
      <h2>{t('Haftalık Plan')}</h2>
      <p className="muted">{t('Zorunlu görevler bitince gün tamamlanır ve seri artar. Zorunlu görevi olmayan gün dinlenme günü sayılır (seriyi bozmaz). Saat girersen hatırlatıcı gelir; "Eğer… o zaman…" alanı başlamayı kolaylaştıran küçük bir plandır.')}</p>

      <div className="phase-tabs">
        {ORDER.map((d) => (
          <button key={d} className={`btn ${d === day ? 'primary' : ''}`} onClick={() => setDay(d)}>
            {dayShort(d)} {(plan[d] || []).length > 0 && <span className="pill soft">{plan[d].length}</span>}
          </button>
        ))}
      </div>

      <h3>{dayName(day)}</h3>
      {tasks.length === 0 && <p className="muted">{t('Görev yok → dinlenme günü 😴 (istersen aşağıdan görev ekle).')}</p>}
      {tasks.map((t, i) => (
        <div key={t.id} className="panel taskedit">
          <input className="grow" placeholder={t('Görev (örn. Matematik: 30 soru)')} value={t.label} onChange={(e) => update(i, { label: e.target.value })} />
          <input type="time" value={t.time} onChange={(e) => update(i, { time: e.target.value })} title={t('Hatırlatma saati')} />
          <input type="number" min="5" max="200" value={t.xp} onChange={(e) => update(i, { xp: Math.max(0, Number(e.target.value) || 0) })} title={t('XP')} style={{ width: 80 }} />
          <label className="inline"><input type="checkbox" checked={t.required} onChange={(e) => update(i, { required: e.target.checked })} /> {t('zorunlu')}</label>
          <button className="link" onClick={() => remove(i)}>{t('sil')}</button>
          <input className="grow full" placeholder={t('Eğer … olursa, o zaman … (örn. Eğer eve gelirsem, çantamı masaya koyup ilk soruyu açarım)')} value={t.cue || ''} onChange={(e) => update(i, { cue: e.target.value })} />
        </div>
      ))}
      <div className="controls">
        <button className="btn primary" onClick={() => setDayTasks(day, [...tasks, newTask()])}>{t('＋ Görev ekle')}</button>
        {tasks.length > 0 && (
          <>
            <button className="btn" onClick={() => copyTo([1, 2, 3, 4, 5])}>{t('Hafta içine kopyala')}</button>
            <button className="btn" onClick={() => copyTo([0, 1, 2, 3, 4, 5, 6])}>{t('Tüm günlere kopyala')}</button>
          </>
        )}
      </div>

      <h3>{t('🤖 AI ile planla')}</h3>
      <textarea className="wide" rows={3} value={desc} onChange={(e) => setDesc(e.target.value)}
        placeholder={t('Durumunu anlat: hangi dersler, günde kaç saat, hangi günler müsait, sınav tarihi… (örn. 11. sınıfım, hafta içi 2 saat, hafta sonu 4 saat, matematik ve fizik zayıf)')} />
      <button className="btn" onClick={ai} disabled={busy || !desc.trim()}>{busy ? t('Plan hazırlanıyor…') : t('Planı oluştur')}</button>
      {err && <div className="error">{err}</div>}

      <h3>{t('📦 Hazır şablonlar')}</h3>
      <div className="controls">
        {Object.entries(PRESETS).map(([id, p]) => (
          <button key={id} className="btn" onClick={() => loadPreset(id)} title={p.desc}>{p.name}</button>
        ))}
      </div>
    </div>
  );
}

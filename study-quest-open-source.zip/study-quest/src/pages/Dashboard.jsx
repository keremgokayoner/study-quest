import { useMemo, useState } from 'react';
import { useT } from '../i18n/useT';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  ReferenceLine,
} from 'recharts';
import { useStore } from '../store/useStore';
import { subjectLabel } from '../data/targets';

const byDate = (a, b) => a.date.localeCompare(b.date) || a.id - b.id;

export default function Dashboard() {
  const t = useT();
  const exams = useStore((s) => s.exams);
  const SUBJECTS = useStore((s) => s.subjects);
  const [sel, setSel] = useState('');

  // Her ders için en son girilen net
  const latest = useMemo(() => {
    const m = {};
    [...exams].sort(byDate).forEach((e) => {
      m[e.subject] = e.net;
    });
    return m;
  }, [exams]);

  if (SUBJECTS.length === 0) {
    return (
      <div>
        <h2>{t('Gelişim Panosu')}</h2>
        <p className="muted">{t('Deneme takibi için Deneme sekmesinden ders ve hedef net ekle; pano burada dolacak.')}</p>
      </div>
    );
  }

  const rows = SUBJECTS.map((s) => ({
    name: subjectLabel(s),
    target: s.target,
    last: latest[s.key] ?? 0,
  }));

  const subj = SUBJECTS.find((s) => s.key === sel) || SUBJECTS[0];
  const series = exams
    .filter((e) => e.subject === subj.key)
    .sort(byDate)
    .map((e) => ({ date: e.date, net: e.net }));

  return (
    <div>
      <h2>{t('Gelişim Panosu')}</h2>

      <div className="progress-grid">
        {SUBJECTS.map((s) => {
          const cur = latest[s.key];
          const pct = cur === undefined ? 0 : Math.max(0, Math.min(100, Math.round((cur / s.target) * 100)));
          return (
            <div key={s.key} className="progress-card">
              <div className="progress-name">{subjectLabel(s)}</div>
              <div className="progress-nums">
                <b>{cur ?? '—'}</b> / {s.target}
              </div>
              <div className="bar">
                <div className="bar-fill" style={{ width: `${pct}%` }} />
              </div>
            </div>
          );
        })}
      </div>

      <h3>{t('Hedef ve son net')}</h3>
      <div className="chart">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={rows} margin={{ top: 8, right: 8, left: -16, bottom: 8 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2a3350" />
            <XAxis dataKey="name" stroke="#9aa6c4" tick={{ fontSize: 11 }} interval={0} angle={-20} textAnchor="end" height={60} />
            <YAxis stroke="#9aa6c4" />
            <Tooltip contentStyle={{ background: '#1a2238', border: '1px solid #2a3350' }} />
            <Legend />
            <Bar dataKey="target" name={t('Hedef')} fill="#f5a623" radius={[4, 4, 0, 0]} />
            <Bar dataKey="last" name={t('Son net')} fill="#4f8cff" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <h3>{t('Zaman içinde gelişim')}</h3>
      <select value={subj.key} onChange={(e) => setSel(e.target.value)}>
        {SUBJECTS.map((s) => (
          <option key={s.key} value={s.key}>
            {subjectLabel(s)}
          </option>
        ))}
      </select>
      <div className="chart">
        {series.length === 0 ? (
          <p className="muted">{t('Bu ders için henüz deneme girilmedi.')}</p>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={series} margin={{ top: 8, right: 16, left: -16, bottom: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a3350" />
              <XAxis dataKey="date" stroke="#9aa6c4" />
              <YAxis stroke="#9aa6c4" domain={[0, subj.max]} />
              <Tooltip contentStyle={{ background: '#1a2238', border: '1px solid #2a3350' }} />
              <ReferenceLine y={subj.target} stroke="#f5a623" strokeDasharray="6 4" label={{ value: t('hedef'), fill: '#f5a623', position: 'right' }} />
              <Line type="monotone" dataKey="net" stroke="#4f8cff" strokeWidth={3} dot={{ r: 4 }} name="Net" />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}

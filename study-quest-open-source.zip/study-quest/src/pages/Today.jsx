import { useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { dayName } from '../data/schedule';
import { todayKey, dayOfWeek } from '../logic/dates';
import { isDayComplete, requiredIds, computeStreak } from '../logic/streak';
import { useNow } from '../hooks/useNow';
import { XP_PACT } from '../data/levels';
import { Starter, Postpone } from '../components/Modals';
import Mascot from '../components/Mascot';
import Ring from '../components/Ring';
import WeekStrip from '../components/WeekStrip';
import { burst, celebrate, sfx } from '../logic/fx';

const go = (tab) => window.dispatchEvent(new CustomEvent('mq-nav', { detail: tab }));

const SAY = {
  start: ['Hadi başlayalım! Sadece 2 dakika 💪', 'İlk adım en kolayı. Hazır mısın?', 'Bugün de bir seviye atlayalım mı?'],
  mid: ['Süper gidiyorsun, devam! 🔥', 'Zinciri kırmak yok!', 'Bir görev daha, sandık yaklaşıyor!'],
  done: ['Bugünü bitirdin! Efsanesin! 🎉', 'Sandığını açmayı unutma 🎁', 'Dinlen, hak ettin!'],
  rest: ['Dinlenme günü. Şarj ol! 😴', 'Bugün serin güvende, keyfine bak.'],
};

export default function Today() {
  const t = useT();
  const days = useStore((s) => s.days);
  const blocks = useStore((s) => s.blocks);
  const plan = useStore((s) => s.plan);
  const profile = useStore((s) => s.profile);
  const pacts = useStore((s) => s.pacts);
  const stats = useStore((s) => s.stats);
  const chests = useStore((s) => s.chests);
  const toggleTask = useStore((s) => s.toggleTask);
  const signPact = useStore((s) => s.signPact);
  const openChest = useStore((s) => s.openChest);
  const frozen = useStore((s) => s.frozen);
  const freeze = useStore((s) => s.inventory.freeze || 0);
  const now = useNow();
  const [starter, setStarter] = useState(null);
  const [postpone, setPostpone] = useState(null);

  const key = todayKey();
  const dow = dayOfWeek(key);
  const tasks = plan[dow] || [];
  const done = days[key]?.done || [];
  const required = requiredIds(plan, key);
  const rest = required.length === 0;
  const complete = isDayComplete(days, key, plan);
  const reqDone = required.filter((id) => done.includes(id)).length;
  const earned = tasks.filter((t) => done.includes(t.id)).reduce((a, t) => a + t.xp, 0);
  const total = tasks.reduce((a, t) => a + t.xp, 0);
  const next = tasks.find((t) => t.required && !done.includes(t.id)) || tasks.find((t) => !done.includes(t.id));
  const st = stats[key] || { starts: 0, postpones: 0 };
  const pact = pacts[key];

  const group = rest ? SAY.rest : complete ? SAY.done : reqDone > 0 ? SAY.mid : SAY.start;
  let say = t(group[(dow + done.length) % group.length]);
  // Taze başlangıç etkisi: hafta/ay başı "temiz sayfa" duygusu motivasyonu artırır
  if (!rest && reqDone === 0 && (dow === 1 || now.getDate() === 1)) say = now.getDate() === 1 ? t('Yeni ay, tertemiz bir sayfa! 🌱') : t('Yeni hafta, tertemiz bir başlangıç! 🌱');
  const streak = computeStreak(days, key, frozen, plan);
  const pct = required.length ? (reqDone / required.length) * 100 : 0;
  const ringColor = pct >= 100 ? 'var(--yellow)' : pct >= 50 ? 'var(--green)' : 'var(--blue)'; // mavi → yeşil → altın
  const risk = streak > 0 && now.getHours() >= 18 && !rest && !complete;
  const mood = rest ? 'sleepy' : complete ? 'cheer' : reqDone > 0 ? 'happy' : 'focus';

  const claim = () => {
    const r = openChest();
    if (!r) return;
    sfx.chest();
    burst(160);
    celebrate(r.type === 'xp'
      ? { emoji: '🎁', title: `+${r.amount} XP!`, text: t('Bugün {xp} XP topladın · seri {streak} gün 🔥 Yarın yeni sandık seni bekliyor!', { xp: earned, streak }) }
      : { emoji: '🧊', title: t('Nadir ödül!'), text: t('Sandıktan bir Seri Dondurma Koruyucusu çıktı!') });
  };

  return (
    <div>
      <div className="hero">
        <Mascot mood={mood} size={110} />
        <div className="speech">
          <div className="muted small">{profile?.name ? `${profile.name} · ` : ''}{dayName(dow)}</div>
          {say}
          {profile?.goal && <div className="muted small">🎯 {profile.goal}</div>}
        </div>
        {!rest && (
          <Ring pct={pct} size={104} stroke={11} color={ringColor}>
            <b>{reqDone}/{required.length}</b>
            <span className="muted small">{t('zorunlu')}</span>
          </Ring>
        )}
      </div>

      <WeekStrip />

      {risk && (
        <div className="banner urgent">
          🔥 {t('{n} günlük serin bugün risk altında, {left} zorunlu görev kaldı.', { n: streak, left: required.length - reqDone })}
          {freeze > 0 && ' ' + t('(🧊 Dondurma koruyucun hazır ama serini kendin koru!)')}{' '}
          {next && <button className="btn" onClick={() => setStarter(next)}>{t('2 dk başla')}</button>}
        </div>
      )}

      {tasks.length === 0 ? (
        <div className="banner">
          {rest && Object.values(plan).some((d) => d.length) ? t('😴 Bugün dinlenme günü. Seri korunuyor.') : t('Henüz planın boş.')}{' '}
          <button className="link plain" onClick={() => go('plan')}>{t('Plan sekmesine git →')}</button>
        </div>
      ) : (
        <>
          {next ? (
            <div className="nowcard">
              <div className="small now-tag">{t('⚡ ŞİMDİ YAP')}</div>
              <div className="now-title">{next.label}</div>
              {next.cue && <div className="muted">🔗 {next.cue}</div>}
              {!rest && !complete && <div className="muted small">{t('Bugün {n} zorunlu görev kaldı, bitirince sandık açılır.', { n: required.length - reqDone })}</div>}
              <div className="controls">
                <button className="btn primary" onClick={() => setStarter(next)}>{t('▶ Sadece 2 dakika başla')}</button>
                <button className="btn" onClick={() => setPostpone(next)}>{t('Ertelemek istiyorum…')}</button>
              </div>
            </div>
          ) : (
            <div className="banner ok">
              {t('🎉 Bugünün tüm görevleri tamam!')}{profile?.reward && <> {t('🎁 Hak ettin: {reward}', { reward: profile.reward })}</>}
            </div>
          )}

          {!rest && (
            <div className={`chest ${complete && !chests[key] ? 'ready' : ''}`}>
              <div className="chest-ico">{chests[key] ? '📭' : complete ? '🎁' : '🔒'}</div>
              <div className="grow">
                <b>{t('Günlük sandık')}</b>
                <div className="muted small">
                  {chests[key] ? t('Bugünkü sandık açıldı. Yarın yenisi gelir!') : complete ? t('Sürpriz ödül seni bekliyor!') : t('Sandığa {n} görev kaldı. İçinden ne çıkacağı sürpriz!', { n: required.length - reqDone })}
                </div>
              </div>
              {complete && !chests[key] && <button className="btn gold" onClick={claim}>{t('Sandığı aç')}</button>}
            </div>
          )}

          {!rest && !complete && next && profile?.reward && (
            <p className="muted small">{t('🎁 Zorunlular bitince: {reward}', { reward: profile.reward })}</p>
          )}

          {!rest && (
            pact ? (
              <div className="banner small">{pact.paid ? t('🤝 Sözünü tuttun! +{n} XP alındı.', { n: XP_PACT }) : t('🤝 Söz verdin. Zorunlu görevleri bitirirsen +{n} XP bonus.', { n: XP_PACT })}</div>
            ) : (
              <div className="banner small">
                {t('🤝 Bugünkü zorunlu görevleri bitireceğine söz ver: tutarsan +{n} XP bonus, tutamazsan ceza yok.', { n: XP_PACT })}{' '}
                <button className="btn" onClick={() => signPact(key)}>{t('Söz veriyorum')}</button>
              </div>
            )
          )}

          <div className="stats-row">
            <div className="stat"><div className="stat-n">{earned}/{total}</div><div className="stat-l">{t('Bugünkü görev XP\'si')}</div></div>
            <div className="stat"><div className="stat-n">{blocks[key] || 0}</div><div className="stat-l">{t('Tamamlanan blok')}</div></div>
            <div className="stat"><div className="stat-n">{st.starts} / {st.postpones}</div><div className="stat-l">{t('Başlama / erteleme')}</div></div>
          </div>

          <ul className="tasks">
            {tasks.map((t) => {
              const isDone = done.includes(t.id);
              return (
                <li key={t.id} className={`task ${isDone ? 'done' : ''}`}>
                  <label>
                    <input type="checkbox" checked={isDone} onChange={() => toggleTask(key, t)} />
                    <span className="check" />
                    <span className="task-label">
                      {t.label}
                      {t.time && <span className="pill">{t.time}</span>}
                      {!t.required && <span className="pill soft">{t('isteğe bağlı')}</span>}
                    </span>
                    <span className="task-xp">+{t.xp} XP</span>
                  </label>
                </li>
              );
            })}
          </ul>
        </>
      )}

      <p className="muted small">
        {t('Kural: 45 dk çalış + 5 dk hızlı tekrar + 10 dk mola. Başlamakta zorlanırsan "2 dakika" butonunu kullan: sadece başla, devamı gelir.')}
      </p>

      {starter && <Starter task={starter} onClose={() => setStarter(null)} />}
      {postpone && <Postpone task={postpone} onClose={() => setPostpone(null)} onStart={() => setStarter(postpone)} />}
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useStore } from '../store/useStore';
import { LANGS, getLang, detectLang } from '../i18n';
import { useT } from '../i18n/useT';
import { buildPlan } from '../logic/planner';
import { YKS_SUBJECTS } from '../data/targets';
import Mascot from '../components/Mascot';

// Araştırmaya göre: bir ekranda tek karar, en fazla 7 adım, hedef sorusu önce ve cevap hemen kullanılır,
// hedef/engel sorularında çoklu seçim, bildirim izni öncesi açıklama, gereksiz soru (yaş vb.) yok.
const PURPOSES = [
  ['school', '🏫 Okul hayatımı düzene sokmak'],
  ['exam', '🎯 Bir sınava hazırlanmak'],
  ['university', '🎓 Üniversite derslerim'],
  ['habit', '🌱 Ders çalışma alışkanlığı kazanmak'],
  ['skill', '🧠 Yeni bir şey / dil öğrenmek'],
  ['work', '💼 Kariyer ve iş gelişimi'],
];
const OBSTACLES = [
  ['procrastinate', '⏳ Başlamayı erteliyorum'],
  ['focus', '📱 Odaklanamıyorum'],
  ['plan', '🗂️ Ne çalışacağımı planlayamıyorum'],
  ['motivation', '🔋 Motivasyonum çabuk düşüyor'],
  ['consistency', '📆 Düzenli olamıyorum'],
];
const TIPS = {
  procrastinate: '⏳ "2 dakika başla" ve Erteleme Kurtarıcı hep elinin altında olacak.',
  focus: '📱 Derin Odak bonusu ve Lo-Fi ile kesintisiz bloklar çalışacaksın.',
  plan: '🗂️ Planı AI ile yeniden yazdırabilir, haftalık planlama görevini kullanabilirsin.',
  motivation: '🔋 Sandık, seri ve kendine verdiğin ödül motivasyonunu taze tutacak.',
  consistency: '📆 Hatırlatıcılar, seri koruma ve "yarının ilk görevi" alışkanlığı oturtacak.',
};
const GRADES = {
  tr: ['Ortaokul', '8. sınıf (LGS)', '9. sınıf', '10. sınıf', '11. sınıf', '12. sınıf', 'Mezun', 'Üniversite', 'Diğer'],
  en: ['Middle school', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12', 'Gap year', 'University', 'Other'],
};
const EXAMS = {
  tr: ['YKS', 'LGS', 'KPSS', 'ALES / YDS', 'Diğer'],
  en: ['SAT', 'ACT', 'IELTS / TOEFL', 'GRE', 'Other'],
};
const MINUTES = [[30, '30 dk (rahat)'], [60, '1 saat'], [120, '2 saat'], [180, '3+ saat (yoğun)']];
const WHENS = [['morning', '🌅 Sabah'], ['afternoon', '☀️ Öğleden sonra'], ['evening', '🌆 Akşam'], ['night', '🌙 Gece']];

export default function Onboarding() {
  const t = useT();
  const setLang = useStore((s) => s.setLang);
  const stored = useStore((s) => s.lang);
  const [step, setStep] = useState(0);
  const [f, setF] = useState({
    purposes: [], grade: '', exam: '', obstacles: [], minutes: 60, days: 6, when: 'evening',
    name: '', goal: '', reward: '', reminders: true, yks: false,
  });
  const [analyzing, setAnalyzing] = useState(false);
  const lang = stored || detectLang();
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const toggle = (k, v, max = 3) => setF((x) => ({ ...x, [k]: x[k].includes(v) ? x[k].filter((y) => y !== v) : [...x[k], v].slice(-max) }));

  const needsLevel = f.purposes.some((p) => ['school', 'exam', 'university'].includes(p));
  const steps = ['lang', 'purpose', ...(needsLevel ? ['level'] : []), 'obstacle', 'rhythm', 'personal', 'summary'];
  const cur = steps[step];
  const total = steps.length;
  const next = () => setStep((s) => Math.min(s + 1, total - 1));
  const back = () => setStep((s) => Math.max(s - 1, 0));

  useEffect(() => {
    if (cur !== 'summary') return;
    setAnalyzing(true);
    const id = setTimeout(() => setAnalyzing(false), 1400); // "cevaplarını analiz ediyorum" geçişi
    return () => clearTimeout(id);
  }, [cur]);

  const result = buildPlan(f);
  const canNext = cur === 'purpose' ? f.purposes.length > 0 : true;

  const finish = async () => {
    const st = useStore.getState();
    let reminders = false;
    if (f.reminders && typeof Notification !== 'undefined') {
      reminders = Notification.permission === 'granted' || (await Notification.requestPermission()) === 'granted';
    }
    const primary = f.purposes[0] || 'habit';
    useStore.setState({
      plan: result.plan,
      subjects: f.yks ? YKS_SUBJECTS : [],
      seedCards: false,
      prefs: { ...st.prefs, reminders, guardTime: f.when === 'night' ? '22:00' : '21:00' },
    });
    st.setProfile({
      name: f.name.trim(), grade: f.grade, exam: primary === 'exam' ? f.exam : '', goal: f.goal.trim(), reward: f.reward.trim(),
      purpose: primary, purposes: f.purposes, obstacles: f.obstacles, minutes: f.minutes, days: f.days, when: f.when,
    });
    st.award(25); // başlangıç hediyesi (endowed progress): çubuk boş başlamaz
  };

  const speech = {
    lang: 'Hangi dilde devam edelim? 🌍',
    purpose: 'Seni tanıyayım: ne için çalışıyorsun?',
    level: 'Harika! Seviyeni bilirsem sorularım ve planım sana göre olur.',
    obstacle: 'Seni en çok ne zorluyor? Ona göre silahlarını hazırlarım ⚔️',
    rhythm: 'Küçük ve sürdürülebilir başlayalım. Düzen, yoğunluktan önemli.',
    personal: 'Son adım! Hepsi isteğe bağlı.',
    summary: analyzing ? 'Cevaplarını analiz ediyorum…' : 'Senin için hazırladım! 🎉',
  }[cur];

  const Opt = ({ on, onClick, children }) => (
    <button className={`preset ${on ? 'on' : ''}`} onClick={onClick}>{children}</button>
  );
  const Chip = ({ on, onClick, children }) => (
    <button className={`chip ${on ? 'on' : ''}`} onClick={onClick}>{children}</button>
  );

  return (
    <div className="onboard wizard">
      <div className="bar wiz-bar"><div className="bar-fill" style={{ width: `${((step + 1) / total) * 100}%` }} /></div>
      <div className="hero">
        <Mascot mood={cur === 'summary' && analyzing ? 'think' : cur === 'summary' ? 'cheer' : 'happy'} size={100} />
        <div className="speech">{t(speech)}</div>
      </div>

      {cur === 'lang' && (
        <div className="presets">
          {LANGS.map((l) => (
            <Opt key={l.id} on={lang === l.id} onClick={() => setLang(l.id)}><b>{l.flag} {l.name}</b></Opt>
          ))}
        </div>
      )}

      {cur === 'purpose' && (
        <>
          <h3>{t('Ne için hazırlanıyorsun?')}</h3>
          <p className="muted small">{t('Birden fazla seçebilirsin (en fazla 3). İlk seçtiğin ana hedefin olur.')}</p>
          <div className="presets">
            {PURPOSES.map(([id, label]) => (
              <Opt key={id} on={f.purposes.includes(id)} onClick={() => toggle('purposes', id)}>
                <b>{t(label)}</b>{f.purposes[0] === id && <span className="muted small">⭐ {t('Ana hedef')}</span>}
              </Opt>
            ))}
          </div>
        </>
      )}

      {cur === 'level' && (
        <>
          <h3>{t('Hangi seviyedesin?')}</h3>
          <div className="chips">
            {(GRADES[getLang()] || GRADES.en).map((g) => <Chip key={g} on={f.grade === g} onClick={() => set('grade', g)}>{g}</Chip>)}
          </div>
          {f.purposes[0] === 'exam' && (
            <>
              <h3>{t('Hangi sınav?')}</h3>
              <div className="chips">
                {(EXAMS[getLang()] || EXAMS.en).map((x) => <Chip key={x} on={f.exam === x} onClick={() => set('exam', x)}>{x}</Chip>)}
              </div>
            </>
          )}
        </>
      )}

      {cur === 'obstacle' && (
        <>
          <h3>{t('Seni en çok ne zorluyor?')}</h3>
          <p className="muted small">{t('En fazla 2 tane seç.')}</p>
          <div className="presets">
            {OBSTACLES.map(([id, label]) => (
              <Opt key={id} on={f.obstacles.includes(id)} onClick={() => toggle('obstacles', id, 2)}><b>{t(label)}</b></Opt>
            ))}
          </div>
        </>
      )}

      {cur === 'rhythm' && (
        <>
          <h3>{t('Günde ne kadar çalışmak istersin?')}</h3>
          <div className="chips">{MINUTES.map(([m, l]) => <Chip key={m} on={f.minutes === m} onClick={() => set('minutes', m)}>{t(l)}</Chip>)}</div>
          <h3>{t('Haftada kaç gün?')}</h3>
          <div className="chips">
            {[5, 6, 7].map((d) => <Chip key={d} on={f.days === d} onClick={() => set('days', d)}>{t('{n} gün', { n: d })}</Chip>)}
          </div>
          {f.days === 7 && <p className="muted small">{t('Dinlenme günü olmazsa seri tatilde de devam ister. Yine de seçebilirsin.')}</p>}
          <h3>{t('Genelde ne zaman çalışırsın?')}</h3>
          <div className="chips">{WHENS.map(([id, l]) => <Chip key={id} on={f.when === id} onClick={() => set('when', id)}>{t(l)}</Chip>)}</div>
          <p className="muted small">{t('Sabit bir zaman seçmek alışkanlığı kolaylaştırır: beyin o saati çalışmaya ayırır.')}</p>
        </>
      )}

      {cur === 'personal' && (
        <>
          <label>{t('Adın')}<input className="wide" value={f.name} onChange={(e) => set('name', e.target.value)} /></label>
          <label>{t('Büyük hedefin (kendi cümlenle)')}
            <input className="wide" placeholder={t('örn. İyi bir üniversite / İngilizceyi akıcı konuşmak')} value={f.goal} onChange={(e) => set('goal', e.target.value)} />
          </label>
          <label>{t('Görevleri bitirince kendine vereceğin ödül 🎁')}
            <input className="wide" placeholder={t('örn. 1 bölüm dizi / 30 dk oyun / bir kahve')} value={f.reward} onChange={(e) => set('reward', e.target.value)} />
          </label>
          <p className="muted small">{t('Sevdiğin şeyi (ödül) zor şeyle (ders) eşleştirmek başlamayı kolaylaştırır.')}</p>
        </>
      )}

      {cur === 'summary' && (analyzing ? (
        <p className="muted wiz-load">⏳ {t('Planın hazırlanıyor…')}</p>
      ) : (
        <>
          <div className="panel">
            <h3>{t('Senin planın')}</h3>
            <ul className="mini-list">
              <li>📅 {t('Haftada {n} gün, günde {b} odak bloğu', { n: result.studyDays, b: result.blocks })}</li>
              <li>⏰ {t('Başlama saatin: yaklaşık {time}', { time: result.firstTime })}</li>
              <li>🔗 {result.cue}</li>
              {f.obstacles.map((o) => <li key={o}>{t(TIPS[o])}</li>)}
              <li>🎁 {t('Başlangıç hediyesi: ilk seviyenin yolunun %25\'i hazır.')}</li>
            </ul>
          </div>
          <label className="inline"><input type="checkbox" checked={f.reminders} onChange={(e) => set('reminders', e.target.checked)} /> {t('Başlama saatinde nazik bir hatırlatma gönder (izin isteyeceğim)')}</label>
          {f.purposes[0] === 'exam' && f.exam === 'YKS' && (
            <><br /><label className="inline"><input type="checkbox" checked={f.yks} onChange={(e) => set('yks', e.target.checked)} /> {t('Deneme takibi için YKS dersleri ve hedef netleri ekle')}</label></>
          )}
          <p className="muted small">{t('Planı sonra Plan sekmesinden değiştirebilir ya da AI ile yeniden yazdırabilirsin.')}</p>
        </>
      ))}

      <div className="controls wiz-nav">
        {step > 0 && <button className="btn" onClick={back}>← {t('Geri')}</button>}
        {cur === 'summary' ? (
          <button className="btn primary big" disabled={analyzing} onClick={finish}>{t('Maceraya başla 🚀')}</button>
        ) : (
          <button className="btn primary big" disabled={!canNext} onClick={next}>{cur === 'personal' ? t('Planımı göster') : t('Devam')}</button>
        )}
        {cur === 'personal' && <button className="link plain" onClick={next}>{t('Atla')}</button>}
      </div>
    </div>
  );
}

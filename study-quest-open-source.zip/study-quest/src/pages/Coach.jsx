import { useEffect, useRef, useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { chat } from '../services/ai';
import { buildContext } from '../logic/context';
import { XP_QUESTION } from '../data/levels';
import Mascot from '../components/Mascot';

const MODES = {
  coach: { label: '🎯 Ders Koçu', hint: 'Soru üretir, çözümünü adım adım kontrol eder. Doğru çözüm başına +10 XP.' },
  hint: { label: '💡 Sokratik İpucu', hint: 'Takıldığın soruyu yaz; cevabı vermez, ipuçlarıyla seni götürür.' },
};

export default function Coach() {
  const t = useT();
  const award = useStore((s) => s.award);
  const [mode, setMode] = useState('coach');
  const [msgs, setMsgs] = useState([]); // { role: 'user'|'model'|'sys', text }
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const endRef = useRef(null);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [msgs, busy]);

  const send = async (text, forceMode) => {
    const m = forceMode || mode;
    if (!text.trim() || busy) return;
    if (forceMode) setMode(forceMode);
    const next = [...msgs, { role: 'user', text: text.trim() }];
    setMsgs(next);
    setInput('');
    setErr('');
    setBusy(true);
    try {
      // Yalnızca gerçek konuşmayı gönder ("sys" XP satırları hariç)
      const { reply, newCorrect } = await chat(next.filter((x) => x.role !== 'sys'), m);
      const n = Math.max(0, Math.min(5, newCorrect || 0));
      const add = [{ role: 'model', text: reply }];
      if (n > 0) {
        award(n * XP_QUESTION);
        add.push({ role: 'sys', text: t('⚡ {n} doğru çözüm · +{xp} XP', { n, xp: n * XP_QUESTION }) });
      }
      setMsgs([...next, ...add]);
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const todayQuiz = () => {
    const c = buildContext(useStore.getState());
    send(
      t('Bugün {day} ve programımda şunlar var: {tasks}. Bu derslerden seviyeme ve hedef sınavıma uygun 3 soru üret (kolaydan zora). Çözümlerimi adım adım kontrol et.', { day: c.dayName, tasks: c.tasks.join('; ') }),
      'coach'
    );
  };

  return (
    <div className="chat-page">
      <div className="hero"><Mascot mood={busy ? 'think' : 'happy'} size={80} /><h2>{t('Bolt · AI Yoldaş')}</h2></div>
      <div className="phase-tabs">
        {Object.entries(MODES).map(([id, v]) => (
          <button key={id} className={`btn ${mode === id ? 'primary' : ''}`} onClick={() => setMode(id)}>
            {t(v.label)}
          </button>
        ))}
        <button className="btn" onClick={todayQuiz} disabled={busy}>{t('📚 Bugünün dersinden 3 soru')}</button>
      </div>
      <p className="muted small">{t(MODES[mode].hint)}</p>

      <div className="chat">
        {msgs.length === 0 && (
          <div className="muted">{t('Selam! Ben Bolt 👋 Soru iste, takıldığın bir soruyu yapıştır ya da yukarıdaki butonla bugünün görevine başla.')}</div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={`bubble ${m.role}`}>{m.text}</div>
        ))}
        {busy && <div className="bubble model muted">{t('Bolt düşünüyor…')}</div>}
        <div ref={endRef} />
      </div>
      {err && <div className="error">{err}</div>}

      <div className="card-form">
        <textarea
          rows={2}
          value={input}
          placeholder={mode === 'hint' ? t('Takıldığın soruyu yaz…') : t('Cevabını ya da isteğini yaz…  (Enter: gönder, Shift+Enter: alt satır)')}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              send(input);
            }
          }}
        />
        <button className="btn primary" disabled={busy} onClick={() => send(input)}>{t('Gönder')}</button>
        <button className="btn" onClick={() => { setMsgs([]); setErr(''); }}>{t('Temizle')}</button>
      </div>
    </div>
  );
}

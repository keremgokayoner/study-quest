import { useStore } from '../store/useStore';
import { useT } from '../i18n/useT';
import { SHOP } from '../data/shop';

export default function Shop() {
  const t = useT();
  const xp = useStore((s) => s.xp);
  const spent = useStore((s) => s.spent);
  const inventory = useStore((s) => s.inventory);
  const buyItem = useStore((s) => s.buyItem);
  const wallet = xp - spent;

  return (
    <div>
      <h2>{t('Mağaza')}</h2>
      <div className="stat"><div className="stat-n">⚡ {wallet}</div><div className="stat-l">{t('Harcanabilir XP (seviyen etkilenmez)')}</div></div>
      <h3>{t('Eşyalar')}</h3>
      {SHOP.map((i) => {
        const have = inventory[i.id] || 0;
        const full = have >= i.max;
        return (
          <div key={i.id} className="panel shop-item">
            <div className="shop-icon">{i.icon}</div>
            <div className="shop-info">
              <b>{t(i.name)}</b> <span className="pill soft">{t('Envanter: {n}/{m}', { n: have, m: i.max })}</span>
              <div className="muted small">{t(i.desc)}</div>
            </div>
            <button className="btn primary" disabled={full || wallet < i.cost} onClick={() => buyItem(i.id)}>
              {full ? t('Dolu') : `${i.cost} XP`}
            </button>
          </div>
        );
      })}
    </div>
  );
}

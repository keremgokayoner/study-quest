import { useEffect, useRef, useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { todayKey } from '../logic/dates';
import { beep, isAmbientOn, startAmbient, stopAmbient } from '../logic/ambient';
import { XP_BLOCK, XP_DEEP } from '../data/levels';
import Ring from '../components/Ring';
import Mascot from '../components/Mascot';

const PHASES = [
  { name: 'Çalışma', min: 45, color: 'var(--blue)', text: 'var(--blue-t)', hint: 'Tek işe odaklan. Telefon uzakta.' },
  { name: 'Hızlı Tekrar', min: 5, color: 'var(--purple)', text: 'var(--purple-t)', hint: 'Az önce öğrendiklerini kendi cümlelerinle özetle.' },
  { name: 'Mola', min: 10, color: 'var(--orange)', text: 'var(--orange-t)', hint: 'Kalk, su iç, gözlerini dinlendir.' },
];

const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

export default function Focus() {
  const t = useT();
  const addBlock = useStore((s) => s.addBlock);
  const blocksToday = useStore((s) => s.blocks[todayKey()] || 0);

  const [phase, setPhase] = useState(0);
  const [left, setLeft] = useState(PHASES[0].min * 60);
  const [running, setRunning] = useState(false);
  const [lofi, setLofi] = useState(isAmbientOn());
  const endRef = useRef(0);
  const leaves = useRef(0); // ders fazında pencereden ayrılma sayısı
  const [leaveN, setLeaveN] = useState(0);

  useEffect(() => {
    if (!(running && phase === 0)) return;
    const off = () => { leaves.current += 1; setLeaveN(leaves.current); };
    window.addEventListener('blur', off);
    return () => window.removeEventListener('blur', off);
  }, [running, phase]);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      const remain = Math.ceil((endRef.current - Date.now()) / 1000);
      if (remain > 0) {
        setLeft(remain);
        return;
      }
      beep(phase === 0 ? 660 : phase === 1 ? 880 : 520);
      if (phase === 1) addBlock(leaves.current === 0); // 45 + 5 tamamlandı → XP (+ Derin Odak bonusu)
      const next = (phase + 1) % PHASES.length;
      if (next === 0) { leaves.current = 0; setLeaveN(0); }
      setPhase(next);
      setLeft(PHASES[next].min * 60);
      endRef.current = Date.now() + PHASES[next].min * 60 * 1000;
    }, 250);
    return () => clearInterval(id);
  }, [running, phase, addBlock]);

  const start = () => {
    endRef.current = Date.now() + left * 1000;
    setRunning(true);
  };
  const pause = () => setRunning(false);
  const reset = () => {
    setRunning(false);
    setPhase(0);
    leaves.current = 0;
    setLeaveN(0);
    setLeft(PHASES[0].min * 60);
  };
  const toggleLofi = () => {
    if (isAmbientOn()) {
      stopAmbient();
      setLofi(false);
    } else {
      startAmbient();
      setLofi(true);
    }
  };

  const p = PHASES[phase];
  const total = p.min * 60;
  const pct = Math.round(((total - left) / total) * 100);

  return (
    <div className="focus">
      <h2>{t('Odak Modu')}</h2>

      <div className="phase-tabs">
        {PHASES.map((ph, i) => (
          <span key={ph.name} className={`phase-tab ${i === phase ? 'active' : ''}`} style={i === phase ? { borderColor: ph.color, color: ph.text } : {}}>
            {t(ph.name)} · {t('{n} dk', { n: ph.min })}
          </span>
        ))}
      </div>

      <div className="timer-wrap">
        <Ring pct={pct} size={300} stroke={18} color={p.color}>
          <div className="timer-phase" style={{ color: p.text }}>{t(p.name)}</div>
          <div className="timer-time">{fmt(left)}</div>
        </Ring>
        <Mascot mood={phase === 2 ? 'sleepy' : running ? 'focus' : 'happy'} size={110} />
        <div className="muted">{t(p.hint)}</div>
      </div>

      <div className="controls">
        {running ? (
          <button className="btn" onClick={pause}>{t('⏸ Duraklat')}</button>
        ) : (
          <button className="btn primary" onClick={start}>{t('▶ Başlat')}</button>
        )}
        <button className="btn" onClick={reset}>{t('↺ Sıfırla')}</button>
        <button className={`btn ${lofi ? 'primary' : ''}`} onClick={toggleLofi}>
          {t('🎧 Lo-Fi')} {lofi ? t('açık') : t('kapalı')}
        </button>
      </div>

      <p className="muted">
        {t('🧠 Derin Odak: ders fazında pencereden ayrılmadan bitirirsen +{xp} XP bonus. Bu blokta ayrılma: {n} (ceza yok, sadece bonusu etkiler).', { xp: XP_DEEP, n: leaveN })}
      </p>
      <p className="muted">
        {t('Bugün tamamlanan blok: {n} · Her 45+5 blok +{xp} XP (yarıda bırakılan blok XP vermez).', { n: blocksToday, xp: XP_BLOCK })}
      </p>
    </div>
  );
}

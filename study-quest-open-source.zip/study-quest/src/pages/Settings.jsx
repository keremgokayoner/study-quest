import { useEffect, useState } from 'react';
import { useT } from '../i18n/useT';
import { getSettings, saveSettings, ping, MODEL_SUGGESTIONS } from '../services/ai';
import { useStore, PERSIST } from '../store/useStore';

export default function Settings() {
  const t = useT();
  const [info, setInfo] = useState(null);
  const [key, setKey] = useState('');
  const [model, setModel] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const profile = useStore((st) => st.profile);
  const prefs = useStore((st) => st.prefs);
  const setProfile = useStore((st) => st.setProfile);
  const setPrefs = useStore((st) => st.setPrefs);
  const [bmsg, setBmsg] = useState('');

  const toggleReminders = async (on) => {
    if (on && typeof Notification !== 'undefined' && Notification.permission !== 'granted') {
      const r = await Notification.requestPermission();
      if (r !== 'granted') return setBmsg(t('Bildirim izni verilmedi; sistem ayarlarından izin vermen gerekebilir.'));
    }
    setPrefs({ reminders: on });
  };
  const exportData = () => {
    const st = useStore.getState();
    const out = {};
    PERSIST.forEach((k) => (out[k] = st[k]));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' }));
    a.download = `study-quest-yedek-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };
  const importData = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f || !confirm(t('Yedek, mevcut tüm verinin yerine geçecek. Devam?'))) return;
    try {
      const data = JSON.parse(await f.text());
      const patch = {};
      PERSIST.forEach((k) => data[k] !== undefined && (patch[k] = data[k]));
      useStore.setState(patch);
      setBmsg(t('Yedek yüklendi.'));
    } catch { setBmsg(t('Dosya okunamadı.')); }
  };

  const refresh = async () => {
    const s = await getSettings();
    setInfo(s);
    setModel(s.model);
  };
  useEffect(() => { refresh(); }, []);

  const save = async () => {
    await saveSettings({ apiKey: key || undefined, model });
    setKey('');
    setMsg(t('Kaydedildi.'));
    refresh();
  };
  const test = async () => {
    setBusy(true); setMsg(t('Test ediliyor…'));
    try { await save(); setMsg(t('✅ Bağlantı tamam (cevap: "{r}")', { r: await ping() })); }
    catch (e) { setMsg(`❌ ${e.message}`); }
    finally { setBusy(false); }
  };
  const remove = async () => { await saveSettings({ apiKey: '' }); setMsg(t('Anahtar silindi.')); refresh(); };

  return (
    <div>
      <h2>{t('Ayarlar')}</h2>
      <h3>{t('Profil')}</h3>
      <div className="settings-form">
        <label>{t('Adın')}<input className="wide" value={profile?.name || ''} onChange={(e) => setProfile({ ...profile, name: e.target.value })} /></label>
        <label>{t('Büyük hedefin')}<input className="wide" value={profile?.goal || ''} onChange={(e) => setProfile({ ...profile, goal: e.target.value })} /></label>
        <label>{t('Ödülün 🎁')}<input className="wide" value={profile?.reward || ''} onChange={(e) => setProfile({ ...profile, reward: e.target.value })} /></label>
      </div>
      <h3>{t('Görünüm ve ses')}</h3>
      <label className="inline"><input type="checkbox" checked={prefs.sound !== false} onChange={(e) => setPrefs({ sound: e.target.checked })} /> {t('Ses efektleri')}</label>{' '}
      <select value={prefs.theme || 'auto'} onChange={(e) => setPrefs({ theme: e.target.value })}>
        <option value="auto">{t('🌓 Otomatik (akşam koyu)')}</option>
        <option value="light">{t('☀️ Açık tema')}</option>
        <option value="dark">{t('🌙 Koyu tema')}</option>
      </select>
      <h3>{t('Hatırlatıcılar')}</h3>
      <label className="inline"><input type="checkbox" checked={prefs.reminders} onChange={(e) => toggleReminders(e.target.checked)} /> {t('Görev saatlerinde bildirim gönder (uygulama açıkken)')}</label>
      <br />
      <label className="inline"><input type="checkbox" checked={prefs.guard} onChange={(e) => setPrefs({ guard: e.target.checked })} /> {t('Akşam "serini koru" hatırlatması')}</label>{' '}
      <input type="time" value={prefs.guardTime || '21:00'} onChange={(e) => setPrefs({ guardTime: e.target.value })} />
      <h3>{t('Yedek')}</h3>
      <div className="controls">
        <button className="btn" onClick={exportData}>{t('⬇️ Verimi yedekle')}</button>
        <label className="btn filebtn">{t('⬆️ Yedekten yükle')}<input type="file" accept="application/json" hidden onChange={importData} /></label>
      </div>
      {bmsg && <div className="muted">{bmsg}</div>}
      <h3>{t('Google Gemini API')}</h3>
      <p className="muted">
        {t('Ücretsiz Gemini anahtarını şu adresten alabilirsin:')} <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">aistudio.google.com/apikey</a>
        <br />
        {t('Anahtar yalnızca bu bilgisayarda saklanır.')}{info?.encrypted ? ' ' + t('(işletim sistemi şifrelemesiyle)') : ''}{' '}
        {t('Not: ücretsiz katmanda Google, girdilerin model geliştirmede kullanılmasına izin verir; bu yüzden kişisel/gizli bilgi yükleme.')}
      </p>
      <div className="settings-form">
        <label>{t('API anahtarı')} {info?.hasKey && <span className="pill">{t('kayıtlı ✓')}</span>}
          <input type="password" className="wide" value={key} placeholder={info?.hasKey ? t('•••••••• (değiştirmek için yeni anahtar yaz)') : 'AIza…'} onChange={(e) => setKey(e.target.value)} />
        </label>
        <label>{t('Model')}
          <input className="wide" list="models" value={model} onChange={(e) => setModel(e.target.value)} />
          <datalist id="models">{MODEL_SUGGESTIONS.map((m) => <option key={m} value={m} />)}</datalist>
        </label>
        <p className="muted small">{t('Model adları sık değişir. 404/kota hatası alırsan listeden başka birini dene (Flash-Lite modelleri ücretsiz kotada en cömert olanlardır).')}</p>
        <div className="controls">
          <button className="btn primary" onClick={save}>{t('Kaydet')}</button>
          <button className="btn" onClick={test} disabled={busy}>{t('Kaydet ve test et')}</button>
          {info?.hasKey && <button className="btn" onClick={remove}>{t('Anahtarı sil')}</button>}
        </div>
        {msg && <div className="muted">{msg}</div>}
      </div>
    </div>
  );
}

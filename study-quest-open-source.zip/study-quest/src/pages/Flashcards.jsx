import { useMemo, useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { SEED_CARDS } from '../data/cards';
import { todayKey } from '../logic/dates';
import { INTERVALS, isDue } from '../logic/leitner';
import { sfx } from '../logic/fx';

const SUBJECT_OPTIONS = ['Matematik', 'Fizik', 'Kimya', 'Biyoloji', 'Türkçe', 'Tarih', 'Coğrafya', 'Diğer'];

export default function Flashcards() {
  const t = useT();
  const customCards = useStore((s) => s.customCards);
  const seedCards = useStore((s) => s.seedCards);
  const cardState = useStore((s) => s.cardState);
  const reviewCard = useStore((s) => s.reviewCard);
  const addCard = useStore((s) => s.addCard);

  const today = todayKey();
  const all = useMemo(() => [...(seedCards ? SEED_CARDS : []), ...customCards], [seedCards, customCards]);
  const due = useMemo(() => all.filter((c) => isDue(cardState[c.id], today)), [all, cardState, today]);
  const boxCounts = useMemo(() => {
    const counts = [0, 0, 0, 0, 0];
    all.forEach((c) => counts[(cardState[c.id]?.box || 1) - 1]++);
    return counts;
  }, [all, cardState]);

  const [show, setShow] = useState(false);
  const [form, setForm] = useState({ subject: 'Matematik', q: '', a: '' });

  const card = due[0];

  const answer = (correct) => {
    if (!correct) sfx.soft();
    reviewCard(card.id, correct);
    setShow(false);
  };

  const submit = (e) => {
    e.preventDefault();
    if (!form.q.trim() || !form.a.trim()) return;
    addCard({ subject: form.subject, q: form.q.trim(), a: form.a.trim() });
    setForm({ ...form, q: '', a: '' });
  };

  return (
    <div>
      <h2>{t('Aralıklı Tekrar (Leitner)')}</h2>

      <div className="boxes">
        {boxCounts.map((n, i) => (
          <div key={i} className="box">
            <div className="box-n">{n}</div>
            <div className="box-l">{t('Kutu {n}', { n: i + 1 })}</div>
            <div className="muted small">{t('{n} günde bir', { n: INTERVALS[i] })}</div>
          </div>
        ))}
      </div>

      {card ? (
        <div className="flashcard slide-in" key={card.id}>
          <div className="muted small">
            {t(card.subject)} · {t('bugün {n} kart kaldı', { n: due.length })}
          </div>
          <div className="fc-q">{card.q}</div>
          {show ? (
            <>
              <div className="fc-a">{card.a}</div>
              <div className="controls">
                <button className="btn warn" onClick={() => answer(false)}>{t('😕 Bilemedim')}</button>
                <button className="btn primary" onClick={() => answer(true)}>{t('😎 Bildim (+3 XP)')}</button>
              </div>
            </>
          ) : (
            <div className="controls">
              <button className="btn primary" onClick={() => setShow(true)}>{t('Cevabı göster')}</button>
            </div>
          )}
        </div>
      ) : (
        <div className="banner ok">{t('✅ Bugünlük tüm kartlar bitti. Yarın görüşürüz!')}</div>
      )}

      <h3>{t('Kendi kartını ekle')}</h3>
      <form className="card-form" onSubmit={submit}>
        <select value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}>
          {SUBJECT_OPTIONS.map((s) => (
            <option key={s} value={s}>{t(s)}</option>
          ))}
        </select>
        <input placeholder={t('Soru / ön yüz')} value={form.q} onChange={(e) => setForm({ ...form, q: e.target.value })} />
        <input placeholder={t('Cevap / arka yüz')} value={form.a} onChange={(e) => setForm({ ...form, a: e.target.value })} />
        <button className="btn primary" type="submit">{t('Ekle')}</button>
      </form>
      <p className="muted small">{t('Toplam {n} kart ({m} tanesi senin).', { n: all.length, m: customCards.length })}</p>
    </div>
  );
}

import { useState } from 'react';
import { useT } from '../i18n/useT';
import { useStore } from '../store/useStore';
import { analyzePdf, blobToBase64 } from '../services/ai';
import { XP_QUESTION } from '../data/levels';
import { sfx } from '../logic/fx';

const MAX_MB = 18; // Gemini satır içi istek sınırı ~20 MB (base64 şişmesi payı bırakıldı)

export default function PdfLab() {
  const t = useT();
  const award = useStore((s) => s.award);
  const addCards = useStore((s) => s.addCards);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [name, setName] = useState('');
  const [res, setRes] = useState(null);
  const [picked, setPicked] = useState({}); // { soruIndex: seçilenIndex }
  const [saved, setSaved] = useState(false);

  const onFile = async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (f.type !== 'application/pdf') return setErr(t('Lütfen bir PDF seç.'));
    if (f.size > MAX_MB * 1024 * 1024) return setErr(t('PDF en fazla {n} MB olabilir. Bölümlere ayırıp yükle.', { n: MAX_MB }));
    setErr(''); setRes(null); setPicked({}); setSaved(false); setName(f.name); setBusy(true);
    try {
      setRes(await analyzePdf(await blobToBase64(f)));
    } catch (ex) {
      setErr(ex.message);
    } finally {
      setBusy(false);
    }
  };

  const pick = (qi, oi) => {
    if (picked[qi] !== undefined) return; // her soru tek hak, XP tek sefer
    setPicked({ ...picked, [qi]: oi });
    if (oi === res.quiz[qi].answerIndex) award(XP_QUESTION);
    else sfx.soft();
  };

  const correct = res ? res.quiz.filter((q, i) => picked[i] === q.answerIndex).length : 0;

  return (
    <div>
      <h2>{t('PDF Analiz Laboratuvarı')}</h2>
      <p className="muted">{t('Ders notu, test ya da kitap bölümü yükle; Bolt özet, flashcard ve 5 soruluk test çıkarsın.')}</p>
      <label className="btn primary filebtn">
        {t('📄 PDF seç')}
        <input type="file" accept="application/pdf" hidden onChange={onFile} disabled={busy} />
      </label>
      {name && <span className="muted"> {name}</span>}
      {busy && <p className="muted">{t('Bolt PDF\'i okuyor… (büyük dosyalarda 30-60 sn sürebilir)')}</p>}
      {err && <div className="error">{err}</div>}

      {res && (
        <>
          <h3>{t('📝 Konu özeti')}</h3>
          <div className="panel pre">{res.summary}</div>

          <h3>{t('🃏 {n} flashcard', { n: res.cards.length })}</h3>
          <ul className="mini-list">
            {res.cards.map((c, i) => (
              <li key={i}><b>{c.q}</b><span className="muted"> → {c.a}</span></li>
            ))}
          </ul>
          <button className="btn primary" disabled={saved} onClick={() => { addCards(res.cards); setSaved(true); }}>
            {saved ? t('✅ Kartlara eklendi') : t('Hepsini Kartlar sekmesine ekle')}
          </button>

          <h3>{t('⚔️ Hızlı test (doğru başına +{n} XP)', { n: XP_QUESTION })}</h3>
          {res.quiz.map((q, qi) => (
            <div key={qi} className="panel">
              <div className="fc-q small-q">{qi + 1}. {q.q}</div>
              {q.options.map((o, oi) => {
                const chosen = picked[qi];
                const cls = chosen === undefined ? '' : oi === q.answerIndex ? 'right' : oi === chosen ? 'wrong' : '';
                return (
                  <button key={oi} className={`opt ${cls}`} onClick={() => pick(qi, oi)}>{o}</button>
                );
              })}
              {picked[qi] !== undefined && <div className="muted small">{q.explanation}</div>}
            </div>
          ))}
          {Object.keys(picked).length === res.quiz.length && res.quiz.length > 0 && (
            <div className="banner ok">{t('Sonuç: {c}/{n} doğru · +{xp} XP kazandın', { c: correct, n: res.quiz.length, xp: correct * XP_QUESTION })}</div>
          )}
        </>
      )}
    </div>
  );
}

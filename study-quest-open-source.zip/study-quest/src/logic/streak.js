import { addDays, dayOfWeek } from './dates';

export const requiredIds = (plan, key) =>
  (plan?.[dayOfWeek(key)] || []).filter((t) => t.required).map((t) => t.id);

// Zorunlu görevi olmayan gün = dinlenme günü: seriyi bozmaz ama artırmaz.
export const isRestDay = (plan, key) => requiredIds(plan, key).length === 0;

export function isDayComplete(days, key, plan) {
  const req = requiredIds(plan, key);
  const done = days[key]?.done || [];
  return req.length > 0 && req.every((id) => done.includes(id));
}

export const isDayCovered = (days, frozen, key, plan) =>
  isDayComplete(days, key, plan) || !!frozen?.[key] || isRestDay(plan, key);

// Bugün tamamsa bugünden, değilse dünden geriye ardışık gün sayısı.
// Dondurulmuş ve dinlenme günleri seriyi sürdürür ama sayaca eklenmez.
export function computeStreak(days, today, frozen = {}, plan = {}) {
  let cursor = isDayComplete(days, today, plan) ? today : addDays(today, -1);
  let n = 0;
  let guard = 0;
  while (guard++ < 3650 && isDayCovered(days, frozen, cursor, plan)) {
    if (isDayComplete(days, cursor, plan)) n++;
    cursor = addDays(cursor, -1);
  }
  return n;
}

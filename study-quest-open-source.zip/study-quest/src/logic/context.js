import { levelInfo } from '../data/levels';
import { dayName } from '../data/schedule';
import { getLang } from '../i18n';
import { computeStreak } from './streak';
import { dayOfWeek, todayKey } from './dates';

// AI'ya verilen öğrenci durumu: Bolt "seni tanıyan" bir yoldaş gibi konuşsun diye.
export function buildContext(state) {
  const key = todayKey();
  const dow = dayOfWeek(key);
  const p = state.profile || {};
  const { level, title } = levelInfo(state.xp, p.goal);
  return {
    name: p.name || '',
    grade: p.grade || '',
    exam: p.exam || '',
    goal: p.goal || '',
    level,
    title,
    streak: computeStreak(state.days, key, state.frozen, state.plan),
    dayName: dayName(dow),
    lang: getLang(),
    purpose: p.purpose || '',
    obstacles: p.obstacles || [],
    tasks: (state.plan?.[dow] || []).map((t) => t.label),
  };
}

import { addDays } from './dates';

// Kutu 1..5 için tekrar aralıkları (gün)
export const INTERVALS = [1, 2, 4, 8, 16];

// Hiç görülmemiş kart (state yok) veya tarihi gelmiş kart tekrar edilmeli.
export const isDue = (state, today) => !state || state.next <= today;

// Doğruysa bir üst kutu, yanlışsa 1. kutu.
export function nextState(state, correct, today) {
  const box = correct ? Math.min((state?.box || 1) + 1, 5) : 1;
  return { box, next: addDays(today, INTERVALS[box - 1]) };
}

import confetti from 'canvas-confetti';
import { levelInfo } from '../data/levels';
import { computeStreak, isDayComplete } from './streak';
import { todayKey } from './dates';
import { T } from '../i18n';

const COLORS = ['#58cc02', '#1cb0f6', '#ffc800', '#ff9600', '#ce82ff'];
export const MILESTONES = [3, 7, 14, 30, 50, 100, 200, 365];
const PRAISE = ['Harika!', 'Süpersin!', 'Efsane!', 'Tam isabet!', 'Durdurulamıyorsun!', 'Bu iş tamam!'];
const pick = (a) => a[Math.floor(Math.random() * a.length)];

let muted = false;

function play(freqs, step = 0.12, vol = 0.18, type = 'triangle') {
  if (muted) return;
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)();
    freqs.forEach((f, i) => {
      const o = c.createOscillator();
      const g = c.createGain();
      const t = c.currentTime + i * step;
      o.type = type;
      o.frequency.value = f;
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + step * 2.5);
      o.connect(g);
      g.connect(c.destination);
      o.start(t);
      o.stop(t + step * 2.5);
    });
    setTimeout(() => c.close(), (freqs.length * step + 0.6) * 1000);
  } catch {
    /* ses çalınamazsa sessizce geç */
  }
}

// Ses efektleri (başka dosyalardan da çağrılır). "soft" cezalandırıcı değil, yumuşak bir "ups".
export const sfx = {
  good: () => play([784, 1047], 0.07, 0.12),
  soft: () => play([330, 262], 0.1, 0.08, 'sine'),
  chest: () => play([523, 659, 784, 1047, 1319, 1568], 0.08, 0.2),
};

const emit = (name, detail) => window.dispatchEvent(new CustomEvent(name, { detail }));
export const toast = (text) => emit('mq-toast', { text });
export const celebrate = (d) => emit('mq-celebrate', d);
export const burst = (n = 90) => confetti({ particleCount: n, spread: 75, origin: { y: 0.7 }, colors: COLORS });

export function missionComplete() {
  burst();
  play([660, 880, 1100]);
  toast(`✅ ${T(pick(PRAISE))}`);
}

export function levelUp({ level, title }) {
  const shot = (x) => confetti({ particleCount: 120, spread: 100, startVelocity: 45, origin: { x, y: 0.6 }, colors: COLORS });
  shot(0.2);
  shot(0.8);
  setTimeout(() => shot(0.5), 250);
  play([523, 659, 784, 1047, 1319], 0.11, 0.22);
  celebrate({ emoji: '🏆', title: T('SEVİYE {n}!', { n: level }), text: T('Yeni unvanın: {title}', { title }) });
}

// Store'u dinler: XP, seviye, blok, gün ve seri kilometre taşları.
export function initFx(store) {
  store.subscribe((s, p) => {
    muted = s.prefs?.sound === false;
    if (!s.hydrated || !p.hydrated) return; // açılışta yüklenen veriyle efekt patlamasın
    const delta = s.xp - p.xp;
    if (delta > 0) emit('mq-xp', { delta });

    const now = levelInfo(s.xp, s.profile?.goal);
    if (now.level > levelInfo(p.xp, p.profile?.goal).level) return levelUp(now);

    const t = todayKey();
    if (s.days !== p.days) {
      const a = computeStreak(s.days, t, s.frozen, s.plan);
      if (a > computeStreak(p.days, t, p.frozen, p.plan) && MILESTONES.includes(a)) {
        burst(180);
        play([523, 659, 784, 1047], 0.1, 0.22);
        return celebrate({ emoji: '🔥', title: T('{n} günlük seri!', { n: a }), text: T('Zinciri kırma, harikasın!') });
      }
    }
    const blockDone = (s.blocks[t] || 0) > (p.blocks[t] || 0);
    const dayDone = !isDayComplete(p.days, t, p.plan) && isDayComplete(s.days, t, s.plan);
    if (blockDone || dayDone) return missionComplete();
    if (delta > 0) sfx.good();
  });
}

import { T } from '../i18n';

// Sihirbaz cevaplarından kişiye göre ilk haftalık planı üretir (AI gerektirmez).
const WHEN = {
  morning: { h: 8, cue: 'kahvaltıdan kalkarsam' },
  afternoon: { h: 16, cue: 'okuldan/işten gelirsem' },
  evening: { h: 19, cue: 'akşam yemeğini bitirirsem' },
  night: { h: 21, cue: 'dişlerimi fırçalamaya gitmeden önce' },
};
const BLOCKS = { 30: 1, 60: 1, 120: 2, 180: 3 };
const MAIN = {
  school: 'Ödevler + günün konularını gözden geçir',
  exam: 'Soru çözümü / konu pratiği',
  university: 'Ders notlarını çalış',
  habit: 'Masaya otur ve 10 dk çalışmaya başla',
  skill: 'Yeni bir şey öğren / pratik yap',
  work: 'Öğrenme bloğu (kurs, okuma, proje)',
};
const pad = (n) => String(n).padStart(2, '0');
const hm = (min) => `${pad(Math.floor(min / 60) % 24)}:${pad(min % 60)}`;

export function buildPlan({ purposes = [], minutes = 60, days = 6, when = 'evening', obstacles = [] }) {
  const w = WHEN[when] || WHEN.evening;
  const n = BLOCKS[minutes] || 1;
  const primary = purposes[0] || 'habit';
  const study = days >= 7 ? [1, 2, 3, 4, 5, 6, 0] : days === 6 ? [1, 2, 3, 4, 5, 6] : [1, 2, 3, 4, 5];
  const cue = T('Eğer {when}, o zaman masama oturup ilk 2 dakikayı başlatırım.', { when: T(w.cue) });
  const plan = {};
  for (let d = 0; d < 7; d++) plan[d] = [];

  study.forEach((d) => {
    const list = [];
    for (let i = 0; i < n; i++) {
      const main = T(MAIN[primary]);
      list.push({
        id: `g-${d}-${i}`,
        label: primary === 'habit' && i === 0 ? main : i === 0 ? T('Odak bloğu: {what}', { what: main }) : T('Odak bloğu {n} (45 dk)', { n: i + 1 }),
        time: hm(w.h * 60 + i * 75),
        xp: primary === 'habit' && i === 0 ? 25 : 40,
        required: true,
        cue: i === 0 ? cue : '',
      });
    }
    if (minutes >= 60) list.push({ id: `g-${d}-rev`, label: T('Bugünkü konuyu 15 dk tekrar et'), time: '', xp: 20, required: false, cue: '' });
    if (primary === 'exam') list.push({ id: `g-${d}-err`, label: T('Hata defteri: yanlışlarını yaz (10 dk)'), time: '', xp: 15, required: false, cue: '' });
    if (primary === 'school') list.push({ id: `g-${d}-next`, label: T('Yarının ders programına göz at (5 dk)'), time: '', xp: 10, required: false, cue: '' });
    if (obstacles.includes('consistency')) list.push({ id: `g-${d}-pick`, label: T('Yarının ilk görevini seç (2 dk)'), time: '21:30', xp: 10, required: false, cue: '' });
    plan[d] = list;
  });
  if (obstacles.includes('plan')) {
    const rest = [0, 6, 5].find((d) => !study.includes(d));
    if (rest !== undefined) plan[rest] = [{ id: 'g-weekly', label: T('Gelecek haftayı planla (isteğe bağlı)'), time: '', xp: 10, required: false, cue: '' }];
  }
  return { plan, firstTime: hm(w.h * 60), cue, blocks: n, studyDays: study.length };
}

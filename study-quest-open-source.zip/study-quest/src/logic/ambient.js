// Dışarıdan ses dosyası gerektirmeyen basit Lo-Fi ortam sesi (kahverengi gürültü + yumuşak akor).
// İstersen src/assets/sounds/ içine kendi mp3'ünü koyup burayı Audio() ile değiştirebilirsin.
let ctx = null;

export const isAmbientOn = () => ctx !== null;

export function startAmbient() {
  if (ctx) return;
  ctx = new (window.AudioContext || window.webkitAudioContext)();

  const master = ctx.createGain();
  master.gain.value = 0.15;
  master.connect(ctx.destination);

  // Kahverengi gürültü (yağmur/radyo hışırtısı gibi)
  const size = 2 * ctx.sampleRate;
  const buffer = ctx.createBuffer(1, size, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < size; i++) {
    const white = Math.random() * 2 - 1;
    last = (last + 0.02 * white) / 1.02;
    data[i] = last * 3.5;
  }
  const noise = ctx.createBufferSource();
  noise.buffer = buffer;
  noise.loop = true;
  const lowpass = ctx.createBiquadFilter();
  lowpass.type = 'lowpass';
  lowpass.frequency.value = 800;
  noise.connect(lowpass);
  lowpass.connect(master);
  noise.start();

  // Am7 akoru, yavaşça dalgalanan sesler
  [220, 261.63, 329.63, 392].forEach((freq, i) => {
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = freq;
    const gain = ctx.createGain();
    gain.gain.value = 0.04;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.1 + i * 0.03;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.03;
    lfo.connect(lfoGain);
    lfoGain.connect(gain.gain);
    osc.connect(gain);
    gain.connect(master);
    osc.start();
    lfo.start();
  });
}

export function stopAmbient() {
  if (ctx) {
    ctx.close();
    ctx = null;
  }
}

export function beep(freq = 880) {
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)();
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.2, c.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.6);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start();
    osc.stop(c.currentTime + 0.6);
    setTimeout(() => c.close(), 800);
  } catch {
    /* ses çalınamazsa sessizce geç */
  }
}

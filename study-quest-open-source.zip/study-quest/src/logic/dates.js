const pad = (n) => String(n).padStart(2, '0');

// Yerel saate göre "YYYY-MM-DD"
export const todayKey = (d = new Date()) =>
  `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

const parse = (key) => {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
};

export const addDays = (key, n) => {
  const d = parse(key);
  d.setDate(d.getDate() + n);
  return todayKey(d);
};

// 0 = Pazar ... 6 = Cumartesi
export const dayOfWeek = (key) => parse(key).getDay();

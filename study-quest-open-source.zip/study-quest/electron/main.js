const { app, BrowserWindow, ipcMain, safeStorage, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');

const dataFile = () => path.join(app.getPath('userData'), 'data.json');

ipcMain.handle('data:load', () => {
  try {
    return JSON.parse(fs.readFileSync(dataFile(), 'utf8'));
  } catch {
    return null;
  }
});

ipcMain.handle('data:save', (_e, data) => {
  fs.mkdirSync(path.dirname(dataFile()), { recursive: true });
  fs.writeFileSync(dataFile(), JSON.stringify(data, null, 2), 'utf8');
  return true;
});

// ---- Gemini ayarları (anahtar işletim sistemi şifreleme servisiyle saklanır) ----
const DEFAULT_MODEL = 'gemini-3.1-flash-lite';
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');
const readSettings = () => {
  try {
    return JSON.parse(fs.readFileSync(settingsFile(), 'utf8'));
  } catch {
    return {};
  }
};
function readKey() {
  const s = readSettings();
  if (!s.apiKey) return '';
  if (!s.enc) return s.apiKey;
  try {
    return safeStorage.decryptString(Buffer.from(s.apiKey, 'base64'));
  } catch {
    return '';
  }
}

ipcMain.handle('settings:get', () => {
  const s = readSettings();
  return { hasKey: !!readKey(), model: s.model || DEFAULT_MODEL, encrypted: !!s.enc };
});

ipcMain.handle('settings:set', (_e, { apiKey, model }) => {
  const s = readSettings();
  if (model) s.model = model.trim();
  if (apiKey !== undefined) {
    if (!apiKey.trim()) {
      delete s.apiKey;
      delete s.enc;
    } else if (safeStorage.isEncryptionAvailable()) {
      s.apiKey = safeStorage.encryptString(apiKey.trim()).toString('base64');
      s.enc = true;
    } else {
      s.apiKey = apiKey.trim();
      s.enc = false;
    }
  }
  fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
  fs.writeFileSync(settingsFile(), JSON.stringify(s), 'utf8');
  return true;
});

// İstek ana süreçten gider: CORS/file:// sorunu olmaz, anahtar renderer'da dolaşmaz.
ipcMain.handle('ai:generate', async (_e, { model, body }) => {
  const key = readKey();
  if (!key) return { error: 'NO_KEY' };
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify(body),
      }
    );
    return { status: res.status, json: await res.json().catch(() => ({})) };
  } catch (e) {
    return { error: 'NETWORK', message: e.message };
  }
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1100,
    height: 760,
    minWidth: 900,
    minHeight: 640,
    backgroundColor: '#0f1420',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  // Dış bağlantılar (örn. AI Studio) varsayılan tarayıcıda açılsın
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  if (process.env.NODE_ENV === 'development') {
    win.loadURL('http://localhost:5173');
  } else {
    win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }
}

app.whenReady().then(() => {
  app.setAppUserModelId('com.studyquest.app'); // Windows bildirimleri için
  // Sesli anlatım için yalnızca mikrofon izni ver
  session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => cb(permission === 'media'));
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

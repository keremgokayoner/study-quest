const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  load: () => ipcRenderer.invoke('data:load'),
  save: (data) => ipcRenderer.invoke('data:save', data),
  // Gemini: API anahtarı yalnızca ana süreçte okunur, renderer'a hiç gelmez.
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (s) => ipcRenderer.invoke('settings:set', s),
  aiGenerate: (req) => ipcRenderer.invoke('ai:generate', req),
});
